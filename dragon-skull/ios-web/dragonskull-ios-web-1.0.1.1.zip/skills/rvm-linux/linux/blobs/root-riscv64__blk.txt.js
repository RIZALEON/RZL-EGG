(self.RVM_BLOBS=self.RVM_BLOBS||{})["root-riscv64/blk.txt"]="ewogIGJsb2NrX3NpemU6IDI1NiwKICBuX2Jsb2NrOiAxNiwKfQo=";
