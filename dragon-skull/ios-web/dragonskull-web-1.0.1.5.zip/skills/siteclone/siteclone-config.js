/* iOS (DRAGON SKULL app web layer): no peer shipped. The device adds its own via window.RDRAGON_PRIVATE_PEERS (bridge/LAN), never a public file. */
window.RDRAGON_SITECLONE_CONFIG={peers:[],readOnly:true,profileId:null};
