/* RDRAGON · CRYPTO SIDE PANEL — CryptoSocial profile inside RDRAGON left slot (#roster). All controls functional, offline (localStorage). t50u–t53u.
   Toggle: × / + or Cmd/Ctrl+Shift+K. ?csp=0 disables. API: window.RDRAGON_CSP */
(function(){
 if(window.__CSP)return;window.__CSP=1;if(/[?&]csp=0/.test(location.search))return;
 var LS="rdragon.csp.v2",base=(document.currentScript&&document.currentScript.src||"").replace(/[^/]*$/,"")||"./skills/crypto-side-panel/";
 var D={on:true,tab:"Posts",nav:"home",rdg:"0.00",following:0,followers:0,follow:{},avatar:"",banner:"",
  eng:{reply:13,repost:3,like:3,views:378,liked:false,reposted:false},replies:[],posts:[],alerts:["Welcome to CryptoSocial on RDRAGON"],msgs:[],prof:{title:"Anti Social CryptoSocial Media",name:"Rizal the Younger",handle:"@chaserizal",bio:"PaleoAnthropologist from the Distant Future | Buy: a.co/d/6zvEHwf | IF OUR WORLD IS A LIE, TRUTH IS THE GREATEST DECEPTION. Give: cash.app/$chaserizal",location:"Mount Olympus, UT",link:"a.co/d/47uq2zX",joined:"April 2019",verified:"SUPER VERIFIED",pname:"Rizal the Valentinian",preply:"Replying to @IGLESIARIZAL",ptext:""}};
 var S;try{S=Object.assign({},D,JSON.parse(localStorage.getItem(LS)||"{}"))}catch(e){S=D}S.prof=Object.assign({},D.prof,S.prof||{});S.bot=S.bot||{};S.draft=[];norm();
 function F(k){return '<span class="csp-ed" contenteditable="plaintext-only" spellcheck="false" data-e="'+k+'" title="click to edit">'+E(S.prof[k])+'</span>'}
 function linkify(s){return E(s).match(/(?:https?:\/\/)?(?:a\.co|cash\.app)\/[^\s|]+/g)||[]}
 function links(s){return linkify(s).map(function(u){return '<a href="'+(/^http/.test(u)?u:"https://"+u)+'" target="_blank" rel="noopener">'+u+' ↗</a>'}).join(" ")}
 function save(){try{localStorage.setItem(LS,JSON.stringify(S))}catch(e){toast("storage full — image too big?")}}
 function E(s){return String(s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})}
 var CASH="https://cash.app/$chaserizal";
 var people=[["@chaserizal","Rizal the Younger"],["@IGLESIARIZAL","Iglesia Rizal"],["@grok","Grok"],["@RDRAGON","RDRAGON"],["@ThundR","ThundR"]];
 var lines=["@grok : Xfile : Professor X","© Aetaneo Rizal : Hortus Edenis","Tales of the Twilight from the Crypt","Beyond the nuclear looking","Jesus Aliens Ghosts &amp; Cryptids","NOVA CONSTELLATIO","#1116 Give cash.app/$chaserizal","Doctor rerum zcientiarum luznaturalium","❤"];
 var stub={Video:["Tales of the Twilight — teaser","NOVA CONSTELLATIO — starfield loop","RDRAGON offline image-gen demo"],
  Articles:["IF OUR WORLD IS A LIE, TRUTH IS THE GREATEST DECEPTION","PaleoAnthropology from the Distant Future","Hortus Edenis — notes"],
  Projects:["RDRAGON · Neo + iOS","THUNDR · free-floating","Project BOTZURECTION","PROJECT-XYZR","CryptoSocial · RDG wallet"]};
 var p,tt;
  /* rt1 (2026-10-25): canned/keyword-echo auto-replies REMOVED. This device never writes RDRAGON answers.
     Every post/comment/reply at any depth -> signed rdragon.ask in the rsync-core outbox (window.RDRAGON_THREAD). RDRAGON on the Neo answers on sync.
     Until an answered rdragon.reply arrives the thread shows "RDRAGON is offline and will answer when synced." Feedback (👍/👎/✎) is private, outbox to Neo only. */
  var RT=(window.RDRAGON_THREAD&&window.RDRAGON_THREAD.create({by:"@chaserizal",device:"17e",storage:window.localStorage,replica:window.RDRAGON_REPLICA||null}))||null; window.RDRAGON_RT=RT;
 function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
 function norm(){S.posts=(S.posts||[]).map(function(x){return typeof x==="string"?{id:uid(),t:x,media:[],c:[]}:(x.c=x.c||[],x.media=x.media||[],x)});S.replies=(S.replies||[]).map(function(r){return typeof r==="string"?{id:uid(),t:r}:r})}
  function fb(){return RT?RT.OFFLINE:"RDRAGON is offline and will answer when synced."}
  function bot(id,t,media,parent){if(!RT||RT.state().nodes[id])return;var par=parent&&parent.pid?parent.pid:parent&&parent.id?parent.id:null;RT.node({id:id,par:par,t:t,media:media||[]});RT.ask(id)}
  function ai(){/* rt1: no on-device answering */}
  function bk(id){if(!RT)return "";if(!RT.state().nodes[id])return "";return RT.children(id).filter(function(k){return k.rd}).map(function(k){return RT._h(k,1)}).join("")}
  function tree(id){return RT&&RT.state().nodes[id]?RT.children(id).map(function(k){return RT._h(k,1)}).join(""):""}
  function retry(){if(RT&&window.RDRAGON_REPLICA&&window.RDRAGON_REPLICA.entries)RT.ingest(window.RDRAGON_REPLICA.entries());if(p)render()}window.addEventListener("online",retry);setInterval(retry,60000);if(window.RDRAGON_REPLICA&&window.RDRAGON_REPLICA.onChange)window.RDRAGON_REPLICA.onChange(function(r){if(RT){RT.ingest(r.added);render()}});window.addEventListener("hashchange",function(){if(RT)RT.open(document,location.hash)});
 function attach(){var i=document.createElement("input");i.type="file";i.accept="image/*,video/*";i.onchange=function(){var f=i.files&&i.files[0];if(!f)return;var m={id:uid(),name:f.name,type:/^video/.test(f.type)?"video":"image"};
  function done(u){m.src=u;S.draft=(S.draft||[]).concat([m]);var ta=p.querySelector("#csp-new"),keep=ta?ta.value:"";render();var t2=p.querySelector("#csp-new");if(t2)t2.value=keep;toast(m.type+" attached · "+f.name)}
  if(m.type==="image")return shrink(f,900,done);var v=document.createElement("video"),url=URL.createObjectURL(f);v.muted=true;v.preload="auto";v.src=url;v.onloadeddata=function(){v.currentTime=Math.min(1,(v.duration||2)/2)};v.onseeked=function(){var c=document.createElement("canvas"),k=Math.min(1,900/Math.max(v.videoWidth,v.videoHeight));c.width=Math.round(v.videoWidth*k);c.height=Math.round(v.videoHeight*k);c.getContext("2d").drawImage(v,0,0,c.width,c.height);URL.revokeObjectURL(url);done(c.toDataURL("image/jpeg",.8))}};i.click()}
 function mhtml(ms){return (ms||[]).map(function(m){return '<div class="csp-img" style="height:140px;background-image:url('+m.src+')" title="'+E(m.type+" · "+m.name)+'">'+(m.type==="video"?'<span class="csp-dim">▶ '+E(m.name)+'</span>':'')+'</div>'}).join("")}
 function toast(m){var t=p.querySelector(".csp-toast");t.textContent=m;t.style.display="block";clearTimeout(tt);tt=setTimeout(function(){t.style.display="none"},2600)}
 function img(k,def){return S[k]?'url('+S[k]+')':'url('+base+'assets/'+def+')'}
 function postCard(){var e=S.eng;return '<div class="csp-card"><div class="l w">'+F("pname")+'</div><div class="rep">'+F("preply")+'</div>'+'<div class="csp-ed csp-ptext" contenteditable="plaintext-only" spellcheck="false" data-e="ptext" title="click to edit post">'+(S.prof.ptext?E(S.prof.ptext):lines.map(function(l){return "✓ "+l}).join("\n"))+'</div>'+
  '<div class="csp-img" style="background-image:url('+base+'assets/post.jpg)"></div>'+
  '<div class="csp-eng"><span data-a="reply">💬 '+e.reply+'</span><span data-a="repost" class="rp'+(e.reposted?' on':'')+'">🔁 '+e.repost+'</span><span data-a="like" class="'+(e.liked?'on':'')+'">♥ '+e.like+'</span><span data-a="views">📊 '+e.views+'</span></div>'+
  '<div class="csp-replybox" style="display:none"><input class="csp-in" placeholder="reply…" maxlength="280"><button data-a="sendreply">reply</button></div>'+
  S.replies.map(function(r){return RT&&RT.state().nodes[r.id]?RT.html(r.id,1):'<div class="csp-row"><span>↳ '+E(r.t)+'</span></div>'}).join("")+'</div>'}
 function view(){var v="";
  if(S.nav==="search")v='<input class="csp-in" id="csp-q" placeholder="search people, posts, #tags" autofocus><div id="csp-res"></div>';
  else if(S.nav==="compose")v='<textarea class="csp-in" id="csp-new" rows="4" maxlength="500" placeholder="what\'s happening, Decider?"></textarea>'+mhtml(S.draft)+'<button data-a="attach">📎 photo/video</button> <button data-a="post">post</button> <button data-a="home">cancel</button>';
  else if(S.nav==="alerts")v=S.alerts.slice().reverse().map(function(a){return '<div class="csp-row"><span>🔔 '+E(a)+'</span></div>'}).join("")+'<button data-a="clearalerts">clear</button>';
  else if(S.nav==="msgs")v=(S.msgs.length?S.msgs.map(function(m){return '<div class="csp-row"><span>✉ '+E(m)+'</span></div>'}).join(""):'<div class="csp-dim">no messages (offline inbox)</div>')+'<input class="csp-in" id="csp-msg" placeholder="message to self / note"><button data-a="sendmsg">send</button>';
  else if(S.nav==="people")v='<div class="csp-dim">&gt; who_to_follow</div>'+people.map(function(x){var on=S.follow[x[0]];return '<div class="csp-row"><span>'+x[0]+'<br><span class="csp-dim">'+x[1]+'</span></span><button data-a="follow" data-h="'+x[0]+'">'+(on?'following':'+ follow')+'</button></div>'}).join("");
  else if(S.tab==="Posts")v=S.posts.map(function(t,i){return [t,i]}).reverse().map(function(x){var o=x[0];return '<div class="csp-card"><div class="l w">'+E(S.prof.name)+' <span class="csp-dim">'+E(S.prof.handle)+'</span><button class="csp-x" data-a="delpost" data-i="'+x[1]+'" title="delete post">✕</button></div><div class="l" style="white-space:pre-wrap">'+E(o.t)+'</div>'+mhtml(o.media)+'<a href="#post/'+E(o.id)+'" class="rt-link csp-dim">#post</a>'+'<div class="csp-eng"><span data-a="reply">💬 '+o.c.length+'</span></div><div class="csp-replybox" style="display:none"><input class="csp-in" placeholder="comment…" maxlength="280"><button data-a="sendcomment" data-i="'+x[1]+'">reply</button></div>'+tree(o.id)+'</div>'}).join("")+postCard();
  else v=stub[S.tab].map(function(t,i){return '<div class="csp-card" data-a="open" data-i="'+S.tab+': '+E(t)+'"><div class="l">'+E(t)+'</div><div class="csp-dim">'+(S.tab==="Video"?"▶ play (offline stub)":S.tab==="Articles"?"read":"open")+'</div></div>'}).join("");
  return v}
 function render(){var keepScroll=p.scrollTop;
  p.innerHTML='<div class="csp-top">'+F("title")+'<button class="csp-x" data-a="toggle" title="collapse (Cmd/Ctrl+Shift+K)">'+(S.on?'×':'+')+'</button></div>'+
  '<div class="csp-banner" data-a="pickbanner" title="click to change banner" style="background-image:'+img("banner","banner.jpg")+'"><img class="csp-gm" src="'+base+'assets/ghostmachine-logo.jpg" alt="GHOSTMACHINE" title="GHOSTMACHINE"><button class="csp-b csp-bv" data-a="verified" title="'+E(S.prof.verified)+' · click to edit badge">✔ Verified</button><button class="csp-b csp-bw" data-a="wallet" title="RDG wallet · double-click to set balance">&gt; Wallet</button></div>'+
  '<div class="csp-av" data-a="pickavatar" title="click to change profile picture" style="background-image:'+img("avatar","avatar.jpg")+'"></div>'+
  '<div class="csp-name">'+F("name")+'</div><div class="csp-handle">'+F("handle")+'</div>'+
  (S.wopen?'<div class="csp-wx"><div>balance <b>'+S.rdg+' RDG</b> <span class="csp-dim">(local ledger · offline · no keys)</span></div><div style="margin:4px 0"><a href="'+CASH+'" target="_blank" rel="noopener">send via cash.app/$chaserizal ↗</a></div><button data-a="copyhandle">copy $chaserizal</button> <button data-a="wallet">close</button></div>':'')+
  '<div class="csp-bm"><div>'+F("bio")+'<div class="csp-links">'+links(S.prof.bio+" "+S.prof.link)+'</div></div>'+
  '<div class="csp-meta"><div>location · '+F("location")+'</div><div>link · '+F("link")+'</div><div>joined · '+F("joined")+'</div></div>'+
  '<div class="csp-ff"><span data-a="people"><b>'+S.following+'</b> Following</span> · <span data-a="people"><b>'+S.followers+'</b> Followers</span></div></div>'+
  '<div class="csp-tabs">'+["Posts","Video","Articles","Projects"].map(function(t){return '<span data-a="tab" data-t="'+t+'" class="'+(t===S.tab&&S.nav==="home"?'on':'')+'">'+t+'</span>'}).join("")+'</div>'+
  '<div class="csp-view">'+view()+'</div>'+
  '<div class="csp-nav">'+[["home","⌂"],["search","⌕"],["compose","+"],["alerts","🔔"],["msgs","✉"]].map(function(n){return '<span data-a="nav" data-n="'+n[0]+'" class="'+(n[0]==="compose"?'plus ':'')+(S.nav===n[0]?'on':'')+'" title="'+{home:"Home",search:"Search",compose:"New post",alerts:"Alerts",msgs:"Messages"}[n[0]]+'">'+n[1]+'</span>'}).join("")+'</div>'+
  '<div class="csp-ready"><b>C:\\SOCIAL&gt;</b><br>READY.</div><div class="csp-toast" style="display:none"></div>';
  p.classList.toggle("csp-off",!S.on);p.scrollTop=keepScroll;
  var q=p.querySelector("#csp-q");if(q){q.oninput=function(){var s=q.value.toLowerCase(),out=[];if(s){people.forEach(function(x){if((x[0]+x[1]).toLowerCase().indexOf(s)>-1)out.push("👤 "+x[0]+" · "+x[1])});
   [S.prof.name,S.prof.handle,S.prof.bio,S.prof.ptext||""].concat(lines,S.posts.map(function(x){return x.t})).forEach(function(l){if(l.toLowerCase().indexOf(s)>-1)out.push("✓ "+l)});[].concat(stub.Video,stub.Articles,stub.Projects).forEach(function(l){if(l.toLowerCase().indexOf(s)>-1)out.push("• "+l)})}
   p.querySelector("#csp-res").innerHTML=out.length?out.map(function(o){return '<div class="csp-row"><span>'+o+'</span></div>'}).join(""):(s?'<div class="csp-dim">no results</div>':'')};q.focus()}
 }
 function shrink(file,max,cb){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){var k=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext("2d").drawImage(im,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",.85))};im.src=r.result};r.readAsDataURL(file)}
 function pick(key,max){var i=document.createElement("input");i.type="file";i.accept="image/*";i.onchange=function(){var f=i.files&&i.files[0];if(!f)return;shrink(f,max,function(u){S[key]=u;save();render();toast((key==="avatar"?"profile picture":"banner")+" updated · saved offline")})};i.click()}
 function act(a,el){var e=S.eng;switch(a){
  case "toggle":S.on=!S.on;break;
  case "verified":var nv=prompt("Badge text (Cancel = show info)",S.prof.verified);if(nv===null){toast("✔ "+S.prof.verified+" · "+S.prof.handle+" · RDRAGON local identity");return}S.prof.verified=nv.trim()||D.prof.verified;break;
  case "pickbanner":pick("banner",1200);return;case "pickavatar":pick("avatar",400);return;
  case "people":S.nav="people";break;
  case "follow":var h=el.dataset.h;S.follow[h]=!S.follow[h];S.following=Object.keys(S.follow).filter(function(k){return S.follow[k]}).length;S.alerts.push((S.follow[h]?"You followed ":"You unfollowed ")+h);break;
  case "wallet":S.wopen=!S.wopen;break;
  case "copyhandle":(navigator.clipboard?navigator.clipboard.writeText("$chaserizal"):Promise.reject()).then(function(){toast("copied $chaserizal")},function(){toast("$chaserizal")});return;
  case "tab":S.tab=el.dataset.t;S.nav="home";break;
  case "nav":S.nav=el.dataset.n;if(S.nav==="home")S.tab="Posts";break;case "home":S.nav="home";S.tab="Posts";break;
  case "reply":var b=el.closest(".csp-card").querySelector(".csp-replybox");b.style.display=b.style.display==="none"?"block":"none";if(b.style.display==="block")b.querySelector("input").focus();return;
  case "sendreply":var inp=el.parentNode.querySelector("input");if(!inp.value.trim())return toast("type a reply first");var rid=uid();S.replies.push({id:rid,t:inp.value.trim()});bot(rid,inp.value.trim(),[],{t:S.prof.pname+" ("+S.prof.preply+"): "+(S.prof.ptext||lines.join("\n")),media:[]});e.reply++;S.alerts.push("You replied to Rizal the Valentinian");break;
  case "repost":e.reposted=!e.reposted;e.repost+=e.reposted?1:-1;break;
  case "like":e.liked=!e.liked;e.like+=e.liked?1:-1;break;
  case "views":e.views++;toast("📊 "+e.views+" views (local)");save();el.textContent="📊 "+e.views;return;
  case "attach":attach();return;
  case "sendcomment":var ci=el.parentNode.querySelector("input"),po=S.posts[+el.dataset.i];if(!ci.value.trim())return toast("type a comment first");var cid=uid();po.c.push({id:cid,t:ci.value.trim()});bot(cid,ci.value.trim(),[],{pid:po.id});S.alerts.push("You commented on your post");break;
  case "delpost":if(confirm("Delete this post?")){S.posts.splice(+el.dataset.i,1)}break;
  case "post":var t=p.querySelector("#csp-new").value.trim();var dm=S.draft||[];if(!t&&!dm.length)return toast("write something first");var pid=uid();S.posts.push({id:pid,t:t,media:dm,c:[]});S.draft=[];bot(pid,t||"(media only)",dm);S.alerts.push("Posted: "+t.slice(0,40));S.nav="home";S.tab="Posts";break;
  case "rt-reply":var rp=el.dataset.p,rt=prompt("Reply");if(!rt||!rt.trim())return;var nid=uid();bot(nid,rt.trim(),[],{id:rp});S.alerts.push("You replied in a thread");break;
  case "rt-fb":if(RT&&RT.feedback(el.dataset.r,el.dataset.v))toast("thanks · private feedback queued for RDRAGON");return;
  case "rt-fbc":var cr=prompt("Correction for RDRAGON (private, Neo only)");if(cr===null)return;var rv=confirm("Was the answer helpful? OK = yes, Cancel = no")?"up":"down";if(RT&&RT.feedback(el.dataset.r,rv,cr))toast("correction queued privately");return;
  case "clearalerts":S.alerts=[];break;
  case "sendmsg":var m=p.querySelector("#csp-msg").value.trim();if(!m)return toast("type a message");S.msgs.push(m);break;
  case "open":toast(el.dataset.i+" — offline stub");return;
  default:return}
  save();render()}
 function build(){p=document.createElement("aside");p.id="csp-panel";p.setAttribute("aria-label","CRYPTO SIDE PANEL");
  var slot=document.getElementById("roster");(slot||document.body).appendChild(p);
  p.addEventListener("click",function(ev){var el=ev.target.closest("[data-a]");if(!el||!p.contains(el))return;if(el.tagName==="A")return;ev.preventDefault();ev.stopPropagation();act(el.dataset.a,el)});
  p.addEventListener("dblclick",function(ev){var t=ev.target.closest("[data-a]");if(!t)return;var a=t.dataset.a,tx=t.textContent,k=null,o=S,lab;
   if(a==="people"){k=/Following/.test(tx)?"following":"followers"}else if(a==="wallet"){k="rdg"}else if(S.eng&&({reply:1,repost:1,like:1,views:1})[a]){o=S.eng;k=a}
   if(!k)return;ev.preventDefault();var v=prompt("Set "+k,o[k]);if(v===null)return;v=+v;if(isNaN(v))return;o[k]=k==="rdg"?v.toFixed(2):Math.max(0,Math.round(v));save();render();toast(k+" = "+o[k]+" · saved offline")});
  p.addEventListener("focusout",function(ev){var k=ev.target.dataset&&ev.target.dataset.e;if(!k)return;var v=ev.target.innerText.trim();if(k!=="ptext"&&k!=="bio")v=v.replace(/\s+/g," ");S.prof[k]=v||D.prof[k]||"";save();if(k==="bio"||k==="link")render();toast(k+" saved · offline")});
  p.addEventListener("keydown",function(ev){if(ev.key==="Enter"&&ev.target.dataset&&ev.target.dataset.e&&ev.target.dataset.e!=="ptext"&&ev.target.dataset.e!=="bio"){ev.preventDefault();ev.target.blur();return}if(ev.key==="Enter"&&!ev.shiftKey){if(ev.target.id==="csp-msg")act("sendmsg");else if(ev.target.closest&&ev.target.closest(".csp-replybox"))act("sendreply",ev.target)}});
  render()}
 setTimeout(retry,1500);window.RDRAGON_CSP={botReply:bot,thread:RT,attachData:function(m){S.draft=(S.draft||[]).concat([m])},toggle:function(v){S.on=v===undefined?!S.on:!!v;save();render()},setRDG:function(n){S.rdg=(+n||0).toFixed(2);save();render()},reset:function(){localStorage.removeItem(LS);S=JSON.parse(JSON.stringify(D));render()}};
 document.addEventListener("keydown",function(e){if((e.metaKey||e.ctrlKey)&&e.shiftKey&&(e.key==="K"||e.key==="k")){e.preventDefault();window.RDRAGON_CSP.toggle()}});
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",build);else build();
 if(RT)setTimeout(function(){RT.open(document,location.hash)},300);
})();
