/* ЯSYNC transponder routes for the RDRAGON app (2026-10-26). No addresses are shipped in this file.
   Routes, in order: 1) peers this device saved (the Neo on the home Wi-Fi, http://<private-LAN-IP>:8799, set once below);
   2) the app's own loopback peer if one runs; 3) offline outbox: entries queue in local storage and retry every 20 s.
   Writes go only to peers saved here. No write token lives on the phone. */
(function(){var K="rdragon.csp.peers",ok=function(u){return/^http:\/\/(10\.\d{1,3}|172\.(1[6-9]|2\d|3[01])|192\.168)\.\d{1,3}\.\d{1,3}:\d{2,5}$/.test(u)||/^https?:\/\/127\.0\.0\.1:\d{2,5}$/.test(u)};
 var L=[];try{L=JSON.parse(localStorage.getItem(K)||"[]").filter(ok)}catch(e){}
 window.RDRAGON_PRIVATE_PEERS=(window.RDRAGON_PRIVATE_PEERS||[]).concat(L);
 window.RSYNC_APP={peers:function(){return L.slice()},set:function(ip,port){var u="http://"+String(ip).trim()+":"+(port||8799);if(!ok(u))return"refused: private LAN address only (10.x, 172.16-31.x, 192.168.x)";if(L.indexOf(u)<0)L.push(u);localStorage.setItem(K,JSON.stringify(L));return"saved "+u+" · reload to sync"},
  clear:function(){L=[];localStorage.removeItem(K);return"cleared"}};
 function bar(){if(L.length||document.getElementById("rsync-app-bar"))return;var d=document.createElement("div");d.id="rsync-app-bar";d.style.cssText="position:fixed;left:8px;right:8px;bottom:8px;z-index:99999;background:#111;color:#eee;border:1px solid #444;border-radius:10px;padding:8px;font:13px system-ui";
  d.innerHTML='ЯSYNC: Neo address on this Wi-Fi <input id="rsync-ip" placeholder="192.168.x.x" inputmode="decimal" style="width:120px"> <button id="rsync-go">Save</button> <button id="rsync-x">Later</button> <span id="rsync-msg"></span>';
  document.body.appendChild(d);document.getElementById("rsync-go").onclick=function(){var m=window.RSYNC_APP.set(document.getElementById("rsync-ip").value);document.getElementById("rsync-msg").textContent=m;if(/^saved/.test(m))setTimeout(function(){location.reload()},600)};
  document.getElementById("rsync-x").onclick=function(){d.remove()}}
 if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",bar);else bar()})();
