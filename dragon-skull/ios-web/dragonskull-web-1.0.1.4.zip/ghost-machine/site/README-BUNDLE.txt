CryptoSocial GHOSTMACHINE sidebar — offline bundle (cryptosocial-ghostmachine-sidebar-20261025-2019)
Source: rizal.pw branch rdragon-reply-v1 @ ce022f3 (local, unpushed). Open index.html via file:// or any static server.
Contents: CryptoSocial panel (RDRAGON threads, nested replies, image replies, quotes, reactions, read-only lessons/job results),
RKRYPT, ЯSYNC rsync-core + rsync-qr, login page. Relative paths, no CDN.
NO PEERS SHIP: config peers:[] + store-and-forward outbox. Each device supplies peers at runtime via a local
rdragon-cryptosocial/private-peers.json {"peers":[...]} (never bundled) or window.RDRAGON_PRIVATE_PEERS set by the host app.
Excluded: founder package, keys/secrets, private peers, ALL-APPCASTS.json, dev extras (see cryptosocial-ghostmachine-sidebar-20261025-2019-dev/).
Founder PUBLIC descriptor (handle/rid/profile/commitment) remains in config for login verification.
