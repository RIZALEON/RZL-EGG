# ThundR knowledge · casket, wallet, approvals (2026-10-23)

## casket
RCASKET (Mac) is the Secure Enclave crown key in RCONTRALROOM/RCASKET-MAC. It signs approval records into a hash-chained log and never exports a key. ЯCASKET (iPhone 17e, inside ЯBOT) is the phone vault. It holds the sealed ed25519 release key (keyId e5833fdfbbfe), asks Face ID EVERY time, and writes back only signatures. Commands: `casket status`, `casket verify`, `casket pubkey`, `casket sign <text>` (needs approval), `casket propose-trust`.

## wallet
RWALLET (Mac) and Я WALLET (iOS) are VIEW-ONLY. They show public addresses and live balances. They make no sends, import no seed or private key, and never touch FRESHWALLET. Commands: `wallet status`, `wallet balances`, `wallet addresses`. `wallet reveal|export` show public addresses only after approval. `wallet sign` is always refused.

## faceid
The Neo has no Touch ID sensor, so the Face ID on the iPhone 17e is the approver for both the Mac and iOS. The Mac sends a `rzl.casket.sitesignreq.v1` approval request over the ЯVPN relay or devicectl (LAN/USB). On the phone: ЯBOT > ЯCASKET > Update sign request > Face ID. The phone signs the exact text "rzl-approval-v1 / reason / nonce / issued / expires". The Mac verifies it against public key e5833fdfbbfe (openssl + pure-python). Commands: `faceid status`, `touchid status`.

## approvals
Order: 1) Face ID on the phone, 2) Mac password (LocalAuthentication). Requests time out after 120 s and are REFUSED by default. Nonces are single-use (used-approval-nonces.json) and expiry is checked, so replays fail. Nothing ever auto-approves. A decline on the phone simply gives no signature, which means refused. Gated actions: casket sign|init|propose-trust, activate/stop … confirm, wallet reveal|export, and RFORGE builds, deletes and egg signing via `rforge-gate.sh`.

## eggrize
EGGRIZE is the FAILSAFE: a signed restore path. Its signed manifest is never edited. Updates ship as eggs or the appcast (no rebuilds). Eggs are signed only on the phone with Face ID (rlab-phone-sign-egg).

## rules
Never print, move or copy keys. No sends, no seed import. Don't touch FRESHWALLET or the EGGRIZE manifests. TRUSTED-KEYS changes are proposals only, needing the Decider's approval. No auto-approve.

## approvers
The RCASKET-MAC/approvers.json registry lists approved devices. Methods go in priority order: face, then fingerprint, then password as the last resort. The iPhone 17e ЯCASKET approves with Face ID (keyId e5833fdfbbfe). The Neo uses fingerprint if a sensor is ever present, and otherwise its password. Biometric templates never leave a device's Secure Enclave, and each device approves locally. Commands: `approvers list`, `approvers propose <device>` (creates a trust proposal for the Decider). The audit trail is in RAUTH-TOUCHID/gate.log.

## signing
Release eggs and appcast Ed25519 (keyId e5833fdfbbfe) are signed **only** on the iPhone 17e with ЯCASKET Face ID via `rlab-phone-sign-egg` after `rauth-gate` (approvers.json: face → fingerprint → Mac password last resort). Silent Keychain `rlab-sign-approved.sh` is **not** the release path. The private key is never exported; SIGNING-METHOD/ folders hold method/config only (Neo + iOS RFORGE/RCASKET/RWALLET). Do not recreate the Keychain key with a biometric lock unless the owner explicitly asks. Ghost Chain events: `signed-phone-faceid`, `egg-published-private`, `egg-seated`.

Commands ThundR / MCR understand:
- `sign this <STAGEDIR>` / `egg-sign <STAGEDIR>` — Face ID phone gate then sign staged egg (publishes nothing)
- `prompt faceid [reason]` — run rauth-gate (Face ID on 17e; Mac password last resort)
- `signing status` — pending SIGNQUEUE + recent Ghost Chain Face ID lines + approvers
- `about signing` / `about faceid` / `about casket` / `about approvers` — knowledge sections
- `request approval <what>` — MCR approval (phone Face ID preferred via gate / Mac SE)

Approve UI: ЯBOT → ЯCASKET → Update sign request → Face ID. Wrapper in every SIGNING-METHOD/: `./sign.sh`.

## Status bars + one ThundR (2026-10-23)

Chat: `status bar` / `show bars` / `hide bars` / `hide` · `status bar wallet|casket|scan|signing|mcr <0-100|pulse|off>`.

Tiny strips sit under the float label; fuller strips sit inside the chat window. Closed float stays tiny; animation + self-heal keep the pet; strips use `#thundr-strips` (not the old `#thundr-bar` ghost).

**Merge:** ThundR is based in the control room. Every app instance claims a presence lock on MCR `127.0.0.1:8329` (`thundr presence claim|beat|yield`). Priority: float (100) > control-room (90) > embed (50). Lower-priority orbs hide (`th-yielded`) so only one ThundR is open. On iPhone without MCR, in-page dedupe still keeps one figure; cross-app merge needs the Mac MCR.

## Ghost / Xcode commands (L063 · 2026-10-24 02:46 MT · ЯID-0003-P4M6 · ЯМАХ)
ThundR can run: GHOST CURSOR X Y · CLICK LEFT|RIGHT · GHOST CLICK X Y · PRESS BUTTON <name> IN <app> · KEY <combo> · TYPE <text> · MENU <app> > <Menu> > <Item> · SHOT · XNEW <name> · GHOST LOG (+ XCODE, TERMINAL, TERMINALTYPE now also via /api/ds/cmd). Progress shows in my inline STATUS bar; every step + failure/retry is logged to ~/ЯLAB/HANDOFF/shots/ghost-log.jsonl.

## Shot-sense everywhere (L065 · ЯID-0003-P4M6 · ЯМАХ · 2026-10-24 15:35 MDT)
SHOT, SSHOT, SEE, SSHOT SEE work in: DRAGOSKUL :8319 (/api/ds/cmd), ЯSCRIBE (/api/rscribe/cmd), ThundR/RCONTRALROOM :8329 (thundr_chat), ds-hostd :8320 (POST /shotcmd, loopback), RVM guest :8321 (`dctl shot SEE`), ЯBOT + ЯBOWZR macOS (INBOX-COMMANDS.txt → io.rlab.rbot-inbox-bridge), iOS apps (BOTBRIDGE :4873 /shot-sense, paired token). SEE = Vision OCR (rocr) + Granite summary (~50 s on first run). Replies in ~/ЯLAB/HANDOFF/shots.

## optimize (2026-10-25 · taught by ThundR · UNSIGNED · Decider ask)
**Command:** `OPTIMIZE` (aliases `/optimize`, `optimize`, "optimize neo"). Modes: `status` (default report) · `clean` (safe cleanup) · `reclaim` (drop Inactive) · `charts` (open dashboard) · `repair` (clean + kickstart meter + refresh) · `deep` (**Decider GO only**).
**Paths:** `~/ЯLAB/RFORGE/THUNDR/OPTIMIZE/` (optimize-analytics.sh, reclaim-inactive.sh, dashboard.html, live-status.*, reclaim.log) · `TOOLS/optimize.sh` (`--clean`) · `SCROLLS/NEO-8GB-MEMORY-MAP-20261025.md` · `SCROLLS/NEO-CONSTANT-OPTIMIZE-PLAYBOOK-20261025.md` · `SCROLLS/TEACH-BOTS-OPTIMIZE.md` · log `SCROLLS/OPTIMIZE-LOG.jsonl`.
**What optimize.sh does:** status of engines :4979 granite · :4879 heart · :4989 moondream · :8319/:8320 WRAP/ds-hostd; swap, pressure, load, heavy procs, failing LaunchAgents; `--clean` = pycache + stale tmp only. Never kills engines.
**Always sample:** Active · Inactive · Wired · Compressor · Free · Speculative + Swap used (`vm_stat`, `sysctl vm.swapusage`, `memory_pressure -Q`, `kern.memorystatus_vm_pressure_level`, `vm.loadavg`).
**Reclaim:** when Inactive > 500 MB, max once / 10 min (auto on meter tick, 120 s). Method: `sudo -n /usr/sbin/purge` if passwordless; else user-safe capped pressure (≤1 GB, skipped if swap > 2 GB).
**Levels:** GREEN < 70% RAM & swap < 1 GB · YELLOW 70–85% or swap 1–2.5 GB (pressure 2) · RED > 85% or swap > 2.5 GB or load > 20 (pressure 4).
**Idle rules:** YELLOW+: may SIGSTOP :4989 idle > 10 min; RED: also :4879. Always SIGCONT before serving. Image gen only if ARMED and swap < 2.5 GB.
**Never:** kill/unload engines, change flags, disable LaunchAgents, quit apps, sign/publish without Decider GO; never touch the THUNDR-FLOAT figure (stays free-floating, no panel); never print tokens; backup before edits.
**Diagnose after reclaim:** report a Before/After table (Active, Inactive, Wired, Compressor, Free, Swap, RAM %). If Inactive barely drops (e.g. 1607→1599), say so: pages are hot/file-backed; next levers are idle-SIGSTOP of engines, Wired (~2.9 GB) and Grok Bot/Safari renderers — those need GO.

## optimize-constant (Decider GO t38u · 2026-10-25)
Cryptodragon / ThundR **constantly** runs OPTIMIZE on Neo: meter LaunchAgent every ~2 min + ThundR routine every 5 min. Auto reclaim Inactive >500 MB with `sudo -n purge` is **allowed** under this GO (overrides teach-pack “never sudo” for purge only). Still never kill engines, never sign/publish without GO, never touch the free-floating figure.

## optimize-idle-hook (ヒロ handoff · 2026-10-25)
Meter owns scheduling: `neo-drive-meter.sh` calls `reclaim-inactive.sh --auto` then `idle-engines-hook.sh` each tick. No second watchdog LaunchAgent. Heart runs `-ngl 0`. WRAP SIGCONTs heart/moondream before `/engine/`. Image gen **ARMED** (ヒロ); guard swap < 2.5 GB. Never kill engines — only SIGSTOP when idle >10m (YELLOW+: moondream; RED: also heart).


## GIZMO · plug into TerraformЯ (2026-10-29)
**GIZMO** is the in-game AI world builder (`/gizmo`). Any app can propose **builds, updates, additions** and run **diagnostics** through it. Every write is a proposal the Decider approves; approved changes are logged with undo and recorded to RGHOSTCHAIN as `note` · `game_build`. Contract: `~/ЯLAB/RCRYPTOFORGE/TERAFORMR/GIZMO-PLUGIN.md` · clients `TERAFORMR/sdk/gizmo-client.py|js` · shell bridge `http://127.0.0.1:8737/rzl/bridge` (loopback). Never signs, mints or publishes.

### GIZMO verb (ThundR / MCR)
- `GIZMO` / `/gizmo` / `ask gizmo <text>` → routes to TerraformЯ GIZMO via the plug-in contract (`TERAFORMR/sdk/gizmo-client.py`).
- `gizmo status` → shell status + lanes · `gizmo hello` → bridge capabilities · `gizmo diagnose` → read-only diagnostic (needs paired token)
- `gizmo build|update|addition <summary> <ops-json>` → **proposal only**; the Decider approves in the ЯBOWZR Plugins manager. ThundR never approves, applies, signs or mints.
- After approval: `gizmo record <item> <change> <summary>` appends a `note` · `game_build` block to RGHOSTCHAIN.

## GIZMO functions — CRYPTOBOT RGIZMO ADD FUNCTION (taught 2026-11-01)
Command (ThundR / GIZMO chat): `CRYPTOBOT RGIZMO ADD FUNCTION internal flashlight when underground or dark without a torch`
- Router: TERAFORMR/companion/companion_core.py (GFN_RE, gizmo_function); template TERAFORMR/companion/gizmo_fn_templates/flashlight.gd
- Flow: proposal P-xxxx -> type `approve` -> writes game/scripts/gizmo/functions/flashlight.gd + content/gizmo/functions.json -> queued for ThundR/RSYNC pack (pack_on_approve.sh dry-run).
- Known kinds: flashlight (words: flashlight/torch/lamp/light/dark/underground/cave). Already approved once: P-b1c08a6c (in B21+ APKs).
- Never keys/signing/publish from chat; shipping still needs Rizal device signature + RIZAL_PUBLISH_GO.
