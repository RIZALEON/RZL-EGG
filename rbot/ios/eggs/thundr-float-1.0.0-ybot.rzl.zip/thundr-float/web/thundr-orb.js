/* thundr-orb.js · THUNDR free-floating cryptobot for the MCR (0.3.0). Gestures: drag = move (saved) · click = wake · double-click or press-and-hold = chat bar · Esc/double-click = close.
   NATIVE mode (THUNDR-FLOAT.app): window moves + endpoint calls go through window.webkit.messageHandlers.float. WEB mode: element moves, fetch 127.0.0.1:8329.
   No sends, no auto-approve: "request approval" always ends in a Touch ID / password prompt from rcasket on this Mac. */
(function () {
  "use strict";
  if (window.THUNDR_ORB) return;
  const NATIVE = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float);
  const EP = "http://127.0.0.1:8329/v1/call/";
  const MOVE_PX = 4, HOLD_MS = 550, DBL_MS = 260;
  const css = document.createElement("style");
  css.textContent = `#thundr-pin.th-orb{position:fixed!important;left:2px!important;top:2px!important;right:auto!important;bottom:auto!important;z-index:2147483600;width:64px;height:auto;min-height:52px;max-height:56px;overflow:visible!important;cursor:grab;background:none!important;border:0!important;box-shadow:none!important;user-select:none;-webkit-user-select:none;touch-action:none;display:flex;flex-direction:column;align-items:center;gap:0;justify-content:flex-start}
#thundr-pin.th-orb thundr-live{pointer-events:none!important;transform:scale(.68);transform-origin:50% 0;margin:0 0 -8px;height:30px;overflow:visible;max-height:30px}#thundr-pin.th-orb .lbl{font:700 7px system-ui;white-space:nowrap;letter-spacing:-.1px;line-height:9px;background:none!important;padding:0;color:#ffe46b;text-shadow:0 0 3px #000,0 1px 1px #000;margin-top:-1px}
#thundr-pin.th-orb.awake .lbl{color:#7dffb0}#th-chat{position:fixed;z-index:2147483601;width:360px;max-height:300px;display:none;flex-direction:column;background:rgba(18,14,30,.94);border:1px solid #6b4fd8;border-radius:12px;box-shadow:0 8px 30px #000a;font:12px ui-monospace,Menlo,monospace;color:#eee}
#th-chat.open{display:flex}#th-chat .hd{display:flex;gap:6px;align-items:center;padding:6px 8px;border-bottom:1px solid #3a2d70;font:700 12px system-ui;color:#ffe46b}#th-chat .hd span{flex:1}
#th-chat .log{flex:1;overflow:auto;padding:6px 8px;white-space:pre-wrap;min-height:120px;max-height:200px}#th-chat .q{color:#9ad0ff}#th-chat .via{color:#888;font-size:10px}
#th-chat .row{display:flex;gap:4px;padding:6px}#th-chat input{flex:1;background:#0c0a16;color:#fff;border:1px solid #444;border-radius:6px;padding:5px}
#th-chat button{background:#2b2160;color:#fff;border:1px solid #6b4fd8;border-radius:6px;padding:3px 7px;font:600 11px system-ui;cursor:pointer}`;
  document.head.appendChild(css);
  const orb = document.createElement("div"); orb.id = "thundr-pin"; orb.className = "th-orb"; orb.dataset.mcr = "1"; orb.title = "ThundR · drag to move · click to wake · double-click or hold for chat";
  const pet = document.createElement("thundr-live"); pet.setAttribute("state", "idle"); pet.setAttribute("size", "48");
  const HERE = (document.currentScript && document.currentScript.src || location.href).replace(/[^/]*$/, "");
  pet.setAttribute("base", HERE + "thundr/atlas/");
  // rzl-repair (2.2.0.5) "unboxes" the kept THUNDR by forcing *{background-image:none!important} inside its shadow root,
  // which also blanks the sprite sheet. Keep the unbox rule for boxes but give the two sprite layers their image back.
  function unblank() {
    const r = pet.shadowRoot; if (!r) return;
    if (!r.getElementById("mcr-sprite-fix")) { const f = document.createElement("style"); f.id = "mcr-sprite-fix"; f.textContent = ".pet i{background-image:var(--mcr-img)!important}.tx,.tg,ol,.tm{display:none!important}.line{background:none!important;border:0!important;box-shadow:none!important;padding:0!important}"; r.appendChild(f); }
    r.querySelectorAll(".pet i").forEach((i) => { const m = /url\([^)]*\)/.exec(i.style.backgroundImage || ""); if (m) i.style.setProperty("--mcr-img", m[0]); });
    const f = r.getElementById("mcr-sprite-fix"); if (f && f.nextSibling) r.appendChild(f);
  }
  // one THUNDR only: the egg's link/superdragon re-seat a small #thundr-pin after rzl-repair has run; drop any figure that is not this orb
  function dedupe() {
    document.querySelectorAll("#thundr-pin:not(.th-orb), #thundr-bar").forEach((e) => e.remove());
    document.querySelectorAll("thundr-live").forEach((e) => { if (e !== pet) e.remove(); });
  }
  setInterval(() => { unblank(); dedupe(); }, 150);
  const lbl = document.createElement("div"); lbl.className = "lbl"; lbl.textContent = "ThundR · idle";
  orb.append(pet, lbl);
  const chat = document.createElement("div"); chat.id = "th-chat";
  chat.innerHTML = `<div class="hd"><span>⚡ ThundR · RDOS 127.0.0.1:8329</span><button data-q="wallet balances">balances</button><button data-q="rwallet">rwallet</button><button data-q="casket status">casket</button><button data-q="scan">scan</button><button data-q="list models">models</button><button data-x="1">✕</button></div><div class="log"></div><div class="row"><input placeholder="wallet · casket verify · activate X · status · ask anything"><button data-q="request approval">approve…</button></div>`;
  document.body.prepend(orb); document.body.append(chat);
  const log = chat.querySelector(".log"), inp = chat.querySelector("input");
  const st = { awake: false, open: false, state: "sleeping" };
  function setState(s) { st.state = s; pet.setAttribute("state", s); }
  function wake() {
    setState("hatch"); lbl.textContent = "ThundR · waking…";
    setTimeout(() => { setState("success"); }, 900);
    setTimeout(() => { st.awake = true; orb.classList.add("awake"); setState("idle"); lbl.textContent = "ThundR · awake"; }, 1500);
    if (NATIVE) post({ op: "wake" });
  }
  function place() {
    if (NATIVE) { orb.style.setProperty("left", "2px", "important"); orb.style.setProperty("top", "2px", "important"); chat.style.left = "70px"; chat.style.top = "4px"; return; }
    const r = orb.getBoundingClientRect(); let x = r.right + 8, y = r.top;
    if (x + 360 > innerWidth) x = Math.max(4, r.left - 368); if (y + 300 > innerHeight) y = Math.max(4, innerHeight - 304);
    chat.style.left = x + "px"; chat.style.top = y + "px";
  }
  function openChat(v) {
    st.open = v === undefined ? !st.open : v; chat.classList.toggle("open", st.open);
    if (NATIVE) post({ op: "chat", open: st.open });
    place(); if (st.open) { if (!st.awake) wake(); setTimeout(() => inp.focus(), 60); if (!log.textContent) say("ThundR ready. Try: wallet balances · casket verify · signing status · prompt faceid · sign this <dir> · request approval <what>", "parser"); }
  }
  function showImgs(L) { /* 2026-10-30 display (pt251u): inline sprites/images from MCR /v1/sprite (index-allowlisted) */
    const box = document.createElement("div"); box.className = "imgs"; box.style.cssText = "display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 6px";
    (L || []).filter((i) => i && i.url && i.available !== false).slice(0, 6).forEach((i) => {
      const f = document.createElement("figure"); f.style.cssText = "margin:0;max-width:100%;text-align:center;font-size:10px;opacity:.9";
      const im = document.createElement("img"); im.src = "http://127.0.0.1:8329" + i.url; im.alt = i.name || "sprite"; im.title = (i.name || "") + " · " + (i.path || "");
      const sc = i.w && i.h ? Math.max(1, Math.min(6, Math.floor(220 / i.w), Math.floor(160 / i.h))) : 1;
      im.style.cssText = "image-rendering:pixelated;background:#0003;border-radius:4px;max-width:100%;" + (i.w ? "width:" + (i.w * sc) + "px;" : "");
      const c = document.createElement("figcaption"); c.textContent = (i.name || "") + (i.kind ? " · " + String(i.kind).replace(/_/g, " ") : "");
      f.append(im, c); box.append(f); });
    if (box.childNodes.length) { log.append(box); log.scrollTop = log.scrollHeight; }
  }
  function say(t, via, q) {
    const d = document.createElement("div");
    if (q) { d.className = "q"; d.textContent = "› " + t; } else { d.textContent = t; if (via) { const v = document.createElement("div"); v.className = "via"; v.textContent = "via " + via; d.append(v); } }
    log.append(d); log.scrollTop = log.scrollHeight;
  }
  // endpoint call (native: Swift URLSession; web: fetch)
  let seq = 0; const pend = {};
  function post(m) { try { window.webkit.messageHandlers.float.postMessage(m); } catch (e) {} }
  window.THUNDR_REPLY = (id, body) => { const p = pend[id]; if (p) { delete pend[id]; p(body); } };
  function call(tool, text) {
    if (NATIVE) return new Promise((res) => { const id = ++seq; pend[id] = res; post({ op: "call", id, tool, text }); });
    return fetch(EP + tool, { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text }) }).then((r) => r.json()).catch((e) => ({ ok: false, error: "MCR endpoint not reachable (" + e + ") — start it: launch.sh serve, or thundr float on" }));
  }
  window.THUNDR_FEED_SAY = (t, via, q) => say(t, via, q); /* backendfeed 20261030: backend chats render in this feed */
  async function ask(q) {
    q = (q || "").trim(); if (!q) return; window.THUNDR_SENT && window.THUNDR_SENT(q); /* backendfeed 20261030: mark window-typed so not doubled */ if (/^(rwallet|rwallet unified|wallet unified)$/i.test(q)) q = "rwallet unified"; /* RWALLET UNIFIED + Rid link via MCR 8329 (view-only) */ say(q, null, true);
    if (/^(request approval|approve)/i.test(q)) say("Face ID on 17e (or Mac password last resort) — ThundR never approves by itself.", "casket");
    if (/^(signing status|signing-status|sign status)$/i.test(q)) say("Ask MCR: signing status · pending SIGNQUEUE + Ghost Chain Face ID (keyId e5833fdfbbfe).", "signing");
    if (/^(prompt faceid|faceid prompt)/i.test(q)) say("Prompting Face ID gate (rauth-gate). On phone: ЯBOT > ЯCASKET > Update sign request.", "signing");
    if (/^(sign this|egg-sign|sign egg)/i.test(q)) say("Usage via MCR: sign this <STAGEDIR> — Face ID phone sign; publishes nothing.", "signing");
    setState(/approv|casket/i.test(q) ? "working" : "thinking");
    const r = await call(/^\/?gizmo\b[:,]?\s/i.test(q) && !/^gizmolink/i.test(q) ? "gizmo_chat" : "thundr_chat", q); /* GIZMO out of game, same view (display 20261030) */
    setState(r && r.ok !== false ? "success" : "error"); setTimeout(() => setState(st.awake ? "idle" : "sleeping"), 1200);
    say(String(r.reply || r.output || r.error || JSON.stringify(r)).replace(/THUNDR/g, "ThundR"), r.via || (r.ok === false ? "error" : "")); if (r && (r.images || r.image)) showImgs(r.images || [r.image]); if (r.reload) setTimeout(() => location.reload(), 1500);
    if (r && r.rcpm_off) { window.THUNDR_RCPM && window.THUNDR_RCPM.stop(); } else if (r && r.rcpm) { window.THUNDR_RCPM && window.THUNDR_RCPM.start(r.rcpm); } /* 2026-11-03 RCPM: live pipe-monitor view */
    if (r && r.action === "open_panel" && r.url) window.THUNDR_OPEN_PANEL(r.url, r.title); /* TERAFORMR tfrcmd 20261030 */
    if (r && r.action === "gizmo_say" && r.text) { const ok = window.THUNDR_GIZMO_SAY && window.THUNDR_GIZMO_SAY(r.text); if (!ok) say("No game panel open. Type TERAFORMR first, then @gizmo <message>.", "gizmolink"); } /* gizmolink 20261030 */
  }
  chat.addEventListener("click", (e) => { const b = e.target.closest("button"); if (!b) return; if (b.dataset.x) return openChat(false); let q = b.dataset.q; if (q === "request approval") q += " " + (inp.value.trim() || "THUNDR chat approval"); inp.value = ""; ask(q); });
  inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { ask(inp.value); inp.value = ""; } });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && st.open) openChat(false); });
  // gestures
  const KEY = "thundr.orb.pos"; let g = null, clickT = null, lastUp = 0;
  if (!NATIVE) { const p = JSON.parse(localStorage.getItem(KEY) || "null") || { x: innerWidth - 110, y: innerHeight - 140 }; orb.style.setProperty("left", Math.max(0, Math.min(p.x, innerWidth - 84)) + "px", "important"); orb.style.setProperty("top", Math.max(0, Math.min(p.y, innerHeight - 84)) + "px", "important"); } else place();
  orb.addEventListener("pointerdown", (e) => {
    orb.setPointerCapture(e.pointerId);
    g = { x: e.screenX, y: e.screenY, ox: orb.offsetLeft, oy: orb.offsetTop, moved: false, held: false };
    g.hold = setTimeout(() => { if (g && !g.moved) { g.held = true; gesture("hold"); } }, HOLD_MS);
    if (NATIVE) post({ op: "dragstart" });
  });
  addEventListener("pointermove", (e) => {
    if (!g) return; const dx = e.screenX - g.x, dy = e.screenY - g.y;
    if (!g.moved && Math.hypot(dx, dy) < MOVE_PX) return;
    if (!g.moved) { g.moved = true; clearTimeout(g.hold); orb.style.cursor = "grabbing"; }
    if (NATIVE) post({ op: "drag", dx, dy });
    else { orb.style.setProperty("left", Math.max(0, Math.min(innerWidth - 84, g.ox + dx)) + "px", "important"); orb.style.setProperty("top", Math.max(0, Math.min(innerHeight - 84, g.oy + dy)) + "px", "important"); if (st.open) place(); }
  });
  const up = () => {
    if (!g) return; clearTimeout(g.hold); orb.style.cursor = "grab"; const was = g; g = null;
    if (was.moved) { gesture("drag"); if (NATIVE) post({ op: "dragend" }); else localStorage.setItem(KEY, JSON.stringify({ x: orb.offsetLeft, y: orb.offsetTop })); return; }
    if (was.held) return;
    const now = Date.now();
    if (now - lastUp < DBL_MS) { clearTimeout(clickT); lastUp = 0; gesture("dblclick"); return; }
    lastUp = now; clickT = setTimeout(() => gesture("click"), DBL_MS);
  };
  addEventListener("pointerup", up, true); addEventListener("pointercancel", up, true);
  const hist = [];
  function gesture(k) {
    hist.push({ k, t: Date.now() }); if (hist.length > 20) hist.shift();
    if (k === "click") wake(); else if (k === "dblclick") openChat(); else if (k === "hold") openChat(true);
  }
  window.THUNDR_ORB = { version: "0.3.0", native: NATIVE, state: () => ({ ...st, gestures: hist.map((h) => h.k) }), ask, openChat, wake };
})();
/* ThundR display patch: hide stray live status text; debug hook ?chat=1 opens the chat bar (web mode only) */
(function(){try{var s=document.createElement("style");s.textContent="#thundr-status{display:none!important}";document.head.appendChild(s);
if(/[?&]chat=1/.test(location.search))setTimeout(function(){window.THUNDR_ORB&&window.THUNDR_ORB.openChat(true)},800);}catch(e){}})();
/* ThundR BASE FORM self-heal (1.0): runs every 30s + on wake. Rules: tiny animated sprite only, label "ThundR · <state>" under it with no
   background, no panels/pop-ups, one figure, window 68x58 when chat closed. Repairs in place; logs via MCR thundr_chat "selfheal-log:" → selfheal.log. */
(function () {
  const O = window.THUNDR_ORB; if (!O || window.THUNDR_HEAL) return;
  const EP = "http://127.0.0.1:8329/v1/call/thundr_chat";
  function send(text) {
    if (O.native) return new Promise((res) => { const id = 900000 + Math.floor(Math.random() * 99999); const prev = window.THUNDR_REPLY;
      window.THUNDR_REPLY = (i, b) => { if (i === id) { window.THUNDR_REPLY = prev; res(b); } else prev(i, b); };
      try { window.webkit.messageHandlers.float.postMessage({ op: "call", id, tool: "thundr_chat", text }); } catch (e) { res({}); } });
    return fetch(EP, { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text }) }).then((r) => r.json()).catch(() => ({}));
  }
  const vis = (el) => { if (!el) return false; const s = getComputedStyle(el); return s.display !== "none" && s.visibility !== "hidden" && el.offsetWidth > 0; };
  let lastRaf = null;
  function check(why) {
    const fixed = []; const orb = document.getElementById("thundr-pin"); { const m = document.getElementById("th-meter"), l = orb && orb.querySelector(".lbl"); if (m && l && m.nextSibling !== l) { l.before(m); fixed.push("th-meter re-pinned between pet and label"); } } const pet = orb && orb.querySelector("thundr-live"); const lbl = orb && orb.querySelector(".lbl");
    ["thundr-bar", "thundr-pop", "thundr-status"].forEach((id) => { const e = document.getElementById(id); if (vis(e)) { e.style.setProperty("display", "none", "important"); e.hidden = true; fixed.push("hid #" + id); } });
    document.querySelectorAll("thundr-live").forEach((e) => { if (e !== pet) { window.THUNDR_MERGE_DUP && window.THUNDR_MERGE_DUP(e); e.remove(); fixed.push("high-five + absorbed duplicate sprite"); } });
    document.querySelectorAll("#thundr-pin").forEach((e) => { if (e !== orb) { e.remove(); fixed.push("absorbed duplicate figure"); } });
    [...document.body.children].forEach((e) => { if (e === orb || e.id === "th-meter" || e.id === "th-chat" || e.id === "th-mood" || e.id === "th-mini" || e.id === "th-jobs" || e.tagName === "SCRIPT" || e.tagName === "STYLE") return;
      if (vis(e)) { e.style.setProperty("display", "none", "important"); fixed.push("hid stray " + (e.id ? "#" + e.id : e.tagName.toLowerCase())); } });
    if (pet) {
      const tx = pet.shadowRoot && pet.shadowRoot.querySelector(".tx"); if (vis(tx)) { tx.style.setProperty("display", "none", "important"); fixed.push("hid status text"); }
      if (pet.getAttribute("size") !== "48") { pet.setAttribute("size", "48"); fixed.push("sprite size→48"); }
      if (pet.style.animationPlayState === "paused" || pet.dataset.paused) { pet.style.animationPlayState = ""; delete pet.dataset.paused; }
      if (pet._raf === lastRaf || pet._raf == null) { try { cancelAnimationFrame(pet._raf); pet._raf = requestAnimationFrame((x) => pet._tick(x)); fixed.push("restarted idle animation"); } catch (e) {} }
      lastRaf = pet._raf;
    }
    if (lbl) {
      const s = O.state(); const want = s.awake ? "ThundR · awake" : "ThundR · " + (s.state === "sleeping" ? "idle" : s.state);
      if (!/^ThundR · /.test(lbl.textContent)) { lbl.textContent = want; fixed.push("label→" + want); }
      const cs = getComputedStyle(lbl); if (cs.backgroundColor !== "rgba(0, 0, 0, 0)" || cs.backgroundImage !== "none" || parseFloat(cs.borderRadius) > 0 || parseFloat(cs.paddingTop) > 0) { lbl.removeAttribute("style"); lbl.style.setProperty("background", "none", "important"); fixed.push("label bubble removed"); }
      if (pet && lbl.getBoundingClientRect().top < pet.getBoundingClientRect().top + 30) { orb.style.flexDirection = "column"; lbl.style.setProperty("order", "2"); fixed.push("label moved under face"); }
    }
    // keep room for #th-meter OPTIMIZE strip (68x58 clips it); status-open = 236x104 native
    if (O.native && !O.state().open && !(window.THUNDR_STATUS && window.THUNDR_STATUS.active && window.THUNDR_STATUS.active()) && !document.getElementById("th-meter") && (innerWidth !== 68 || innerHeight !== 58)) { try { window.webkit.messageHandlers.float.postMessage({ op: "chat", open: false }); } catch (e) {} fixed.push("window→68x58 (was " + innerWidth + "x" + innerHeight + ")"); }
    // meter now fits in small 68x58 — keep status closed unless THUNDR_STATUS is active
    if (O.native && !O.state().open && document.getElementById("th-meter") && !(window.THUNDR_STATUS && window.THUNDR_STATUS.active && window.THUNDR_STATUS.active()) && (innerWidth !== 68 || innerHeight !== 58)) { try { window.webkit.messageHandlers.float.postMessage({ op: "status", open: false }); window.webkit.messageHandlers.float.postMessage({ op: "chat", open: false }); } catch (e) {} fixed.push("window→68x58 with meter"); }
    if (pet && window.THUNDR_ANIM) { const a = pet.getAnimations ? pet.getAnimations().filter((x) => /th-bob/.test(x.animationName || "")) : [];
      if (!a.length || a.some((x) => x.playState !== "running")) { pet.style.animation = "none"; void pet.offsetWidth; pet.style.animation = ""; a.forEach((x) => x.play()); fixed.push("restarted hover bob"); }
      const _st0 = pet.getAttribute("state"); /* 2026-10-26 idle-fix: idle/sleeping sprite can hold one frame and hidden windows pause rAF; that is rest, not frozen */ if (!document.hidden && _st0 !== "idle" && _st0 !== "sleeping") { const smp = window.THUNDR_ANIM.frameSample(); setTimeout(() => { if (window.THUNDR_ANIM.frameSample() !== smp) return; { try { cancelAnimationFrame(pet._raf); pet._t = 0; pet._f = 0; pet._raf = requestAnimationFrame((x) => pet._tick(x)); const s = pet.getAttribute("state"); if (s !== "idle" && s !== "sleeping") pet.setAttribute("state", pet._rest || "idle"); } catch (e) {} send("selfheal-log: [" + why + "] frozen frame in state " + pet.getAttribute("state") + " → restarted"); } }, 700); } }
    if (fixed.length) send("selfheal-log: [" + why + "] " + fixed.join("; "));
    return fixed;
  }
  function breakLook() { const p = document.getElementById("thundr-pop"); if (p) { p.hidden = false; p.style.setProperty("display", "block", "important"); p.textContent = "ThundR · TEST BREAK panel"; }
    const pet = document.querySelector("#thundr-pin thundr-live"); if (pet) { cancelAnimationFrame(pet._raf); lastRaf = pet._raf; } }
  async function poll() { const r = await send("selfheal-poll"); if (r && Array.isArray(r.gizmo)) r.gizmo.forEach((m) => { if (/^\/?terr?aformr$/i.test(m)) window.THUNDR_GIZMO_OPEN && window.THUNDR_GIZMO_OPEN(); else if (window.THUNDR_GIZMO_SAY) window.THUNDR_GIZMO_SAY(m); }); /* gizmolink 20261030 */ if (r && r.break) breakLook(); if (r && r.reload) location.reload(); if (r && r.check) check("requested"); if (r && r.force && window.THUNDR_ANIM) { if (!(window.THUNDR_MOVES && window.THUNDR_MOVES.play(r.force))) window.THUNDR_ANIM.force(r.force); } }
  setTimeout(() => check("start"), 3000); setInterval(() => check("30s"), 30000); setInterval(poll, 5000);
  const w = O.wake; O.wake = function () { const x = w.apply(this, arguments); setTimeout(() => check("wake"), 1800); return x; };
  try { new MutationObserver(() => { if (/awake$/.test(document.querySelector("#thundr-pin .lbl").textContent)) setTimeout(() => check("wake"), 300); }).observe(document.querySelector("#thundr-pin .lbl"), { childList: true }); } catch (e) {}
  window.THUNDR_HEAL = { check, breakLook, version: "1.0" };
})();
/* ThundR ALWAYS-ANIMATED (1.1): constant slow hover bob in every state, occasional blink, sleep = bob + breathing + Zzz.
   Frames from the ЯBOWZR thundr-live atlas (same files); one-shot states never hold a still frame. */
(function () {
  const orb = document.getElementById("thundr-pin"); if (!orb || window.THUNDR_ANIM) return;
  const pet = orb.querySelector("thundr-live");
  const css = document.createElement("style"); css.id = "thundr-anim-css";
  css.textContent = `@keyframes th-bob{0%,100%{translate:0 0}50%{translate:0 -3px}}
@keyframes th-breathe{0%,100%{scale:1 1}50%{scale:1.04 .96}}
@keyframes th-blink{0%,94%,100%{filter:none}96%{filter:brightness(.55)}}
@keyframes th-z{0%{opacity:0;transform:translate(0,0) scale(.6)}30%{opacity:1}100%{opacity:0;transform:translate(6px,-12px) scale(1)}}
#thundr-pin.th-orb thundr-live{animation:th-bob 2.4s ease-in-out infinite,th-blink 5.3s linear infinite!important}
#thundr-pin.th-orb.sleep thundr-live{animation:th-bob 3.6s ease-in-out infinite,th-breathe 3.6s ease-in-out infinite,th-blink 7s linear infinite!important}
#thundr-pin .zz{position:absolute;left:40px;top:0;font:700 7px system-ui;color:#c9b6ff;text-shadow:0 0 2px #000;pointer-events:none;display:none}
#thundr-pin.sleep .zz{display:block;animation:th-z 2.2s ease-out infinite}#thundr-pin.sleep .zz+.zz{animation-delay:1.1s}`;
  document.head.appendChild(css);
  orb.style.position = "fixed"; for (let i = 0; i < 2; i++) { const z = document.createElement("span"); z.className = "zz"; z.textContent = "z"; orb.append(z); }
  const lbl = orb.querySelector(".lbl");
  function sync() { const s = pet.getAttribute("state"); const sleep = s === "sleeping"; orb.classList.toggle("sleep", sleep); pet._rest = sleep ? "sleeping" : "idle";
    const want = "ThundR · " + (orb.dataset.move ? orb.dataset.move : sleep ? "sleeping" : s === "hatch" ? "waking" : orb.classList.contains("awake") && s === "idle" ? "awake" : s);
    if (lbl && lbl.textContent !== want && !/waking…/.test(lbl.textContent)) lbl.textContent = want;  if (lbl) lbl.style.fontSize = lbl.textContent.length > 14 ? "6px" : ""; }
  if (lbl) new MutationObserver(() => { const n = lbl.textContent.length, f = n > 18 ? "5.5px" : n > 14 ? "6px" : ""; if (lbl.style.fontSize !== f) lbl.style.fontSize = f; }).observe(lbl, { childList: true });
  new MutationObserver(sync).observe(pet, { attributes: true, attributeFilter: ["state"] }); new MutationObserver(sync).observe(orb, { attributes: true, attributeFilter: ["class"] }); sync();
  function force(s) { if (s === "awake") { orb.classList.add("awake"); pet.setAttribute("state", "idle"); }
    else if (s === "wake") { window.THUNDR_ORB.wake(); } else { if (s === "sleeping" || s === "sleep") orb.classList.remove("awake"); pet.setAttribute("state", s === "sleep" ? "sleeping" : s); } }
  function frameSample() { const r = pet.shadowRoot; const els = r ? [...r.querySelectorAll(".pet i")] : []; return els.map((e) => e.style.backgroundPosition + "|" + e.style.opacity).join(";") + "|f" + pet._f; }
  window.THUNDR_ANIM = { force, frameSample, version: "1.1" };
})();
/* ThundR MOVESET (1.2): moods, actions, abilities, gesture reactions, idle auto-moods, chat effects, real sleep (breath bob + snore Zzz/puff + bolt flicker).
   Sprite frames = ЯBOWZR thundr-live atlas (idle/working/thinking/searching/success/error/sleeping/egg/hatch); each move = atlas state + tiny CSS FX layer. */
(function () {
  const A = window.THUNDR_ANIM, O = window.THUNDR_ORB, orb = document.getElementById("thundr-pin"); if (!A || !O || !orb || window.THUNDR_MOVES) return;
  const pet = orb.querySelector("thundr-live"), lbl = orb.querySelector(".lbl");
  const css = document.createElement("style"); css.id = "thundr-moves-css";
  css.textContent = `#thundr-pin .fx{position:absolute;left:0;top:0;width:64px;height:40px;pointer-events:none;overflow:visible}
#thundr-pin .fx b{position:absolute;font:700 9px system-ui;line-height:1;text-shadow:0 0 3px #000}
@keyframes m-jolt{0%,100%{rotate:0}20%{rotate:-8deg}40%{rotate:8deg}60%{rotate:-5deg}80%{rotate:5deg}}
@keyframes m-shake{0%,100%{margin-left:0}25%{margin-left:-2px}75%{margin-left:2px}}
@keyframes m-tremble{0%,100%{margin-left:0}50%{margin-left:1px}}
@keyframes m-tilt{0%,100%{rotate:0}50%{rotate:-12deg}}
@keyframes m-droop{0%,100%{margin-top:0;rotate:0}50%{margin-top:3px;rotate:6deg}}
@keyframes m-jump{0%,100%{margin-top:0}40%{margin-top:-9px}60%{margin-top:-9px}}
@keyframes m-spin{to{rotate:360deg}}
@keyframes m-wave{0%,100%{rotate:0}25%{rotate:14deg}75%{rotate:-14deg}}
@keyframes m-fly{0%,100%{margin-top:-4px;rotate:-6deg}50%{margin-top:-7px;rotate:6deg}}
@keyframes m-cloud{0%,100%{opacity:1;filter:none}50%{opacity:.45;filter:blur(1.5px) saturate(.5)}}
@keyframes m-chaos{0%{filter:hue-rotate(0)}100%{filter:hue-rotate(360deg)}}
@keyframes m-flash{0%,100%{filter:none}10%,30%{filter:brightness(2.2) drop-shadow(0 0 4px #ffe46b)}20%{filter:brightness(.8)}}
@keyframes m-gloom{0%,100%{filter:brightness(.6) saturate(.6)}50%{filter:brightness(.5) saturate(.4)}}
@keyframes fx-up{0%{opacity:0;transform:translate(0,4px) scale(.6)}25%{opacity:1}100%{opacity:0;transform:translate(var(--dx,0),-14px) scale(1.1)}}
@keyframes fx-fall{0%{opacity:1;transform:translate(0,0)}100%{opacity:0;transform:translate(var(--dx,0),22px)}}
@keyframes fx-bolt{0%,100%{opacity:0}10%,40%{opacity:1}25%{opacity:.2}}
@keyframes fx-puff{0%{opacity:0;transform:scale(.3)}40%{opacity:.8;transform:scale(1)}100%{opacity:0;transform:scale(1.4) translate(4px,-4px)}}
@keyframes fx-flick{0%,100%{opacity:.25;rotate:-8deg}30%{opacity:1;rotate:6deg}55%{opacity:.4;rotate:-4deg}80%{opacity:.95;rotate:8deg}}
#thundr-pin.sleep .zz{font-size:8px}
#thundr-pin .snore{position:absolute;left:36px;top:18px;width:6px;height:6px;border-radius:50%;background:rgba(220,210,255,.7);display:none;pointer-events:none}
#thundr-pin.sleep .snore{display:block;animation:fx-puff 3.6s ease-out infinite}
#thundr-pin .bolt{position:absolute;left:28px;top:24px;font:700 9px system-ui;color:#ffe46b;text-shadow:0 0 4px #ffb800;display:none;pointer-events:none}
#thundr-pin.sleep .bolt{display:block;animation:fx-flick 1.7s steps(6) infinite}`;
  document.head.appendChild(css);
  const fx = document.createElement("div"); fx.className = "fx"; orb.append(fx);
  const sn = document.createElement("span"); sn.className = "snore"; orb.append(sn);
  const bo = document.createElement("span"); bo.className = "bolt"; bo.textContent = "⚡"; orb.append(bo);
  function spark(ch, x, y, color, kind, ms, dx) { const b = document.createElement("b"); b.textContent = ch; b.style.cssText = `left:${x}px;top:${y}px;color:${color};--dx:${dx || 0}px;animation:${kind || "fx-up"} ${ms || 900}ms ease-out forwards`; fx.append(b); setTimeout(() => b.remove(), (ms || 900) + 50); }
  // move table: [atlas state, extra pet animation, duration ms, fx fn]
  const M = {
    poke:        ["success", "m-jolt .5s ease 1", 900, () => spark("!", 46, 0, "#ffe46b")],
    shocked:     ["error", "m-jolt .35s ease 3", 1300, () => { spark("!", 44, -2, "#ff6b6b"); spark("!", 50, 2, "#ff6b6b", "fx-up", 900, 4); }],
    mischievous: ["thinking", "m-tilt 1.2s ease-in-out 2", 2600, () => spark("😈", 46, 0, "#c9b6ff", "fx-up", 1400)],
    worried:     ["searching", "m-tremble .12s linear 16", 2200, () => spark("💧", 44, 2, "#8fd3ff", "fx-fall", 1200)],
    sad:         ["sleeping", "m-droop 1.6s ease-in-out 2", 3200, () => spark("💧", 22, 14, "#8fd3ff", "fx-fall", 1500)],
    facepalm:    ["error", "m-droop .9s ease-in-out 2", 2000, () => spark("🤦", 44, 0, "#fff", "fx-up", 1400)],
    tired:       ["sleeping", "m-droop 2s ease-in-out 1", 2400, () => spark("…", 44, 4, "#ccc", "fx-up", 1600)],
    sleepy:      ["sleeping", "m-droop 2.4s ease-in-out 1", 2600, () => spark("z", 46, 0, "#c9b6ff", "fx-up", 1600)],
    determined:  ["working", "m-shake .2s linear 6", 2000, () => spark("💢", 46, 0, "#ff8a3d", "fx-up", 1200)],
    smug:        ["success", "m-tilt 1.4s ease-in-out 1", 2000, () => spark("✨", 46, 0, "#ffe46b", "fx-up", 1200)],
    yelling:     ["error", "m-shake .08s linear 20", 1800, () => { spark("!!", 44, -2, "#ff6b6b"); spark("💢", 6, 2, "#ff6b6b"); }],
    nervous:     ["searching", "m-tremble .08s linear 22", 1900, () => spark("💦", 46, 2, "#8fd3ff", "fx-fall", 1200)],
    gloomy:      ["sleeping", "m-gloom 1.5s ease-in-out 2", 3000, () => spark("☁", 44, -2, "#888", "fx-up", 2000)],
    grimace:     ["error", "m-tremble .1s linear 12", 1500, () => spark("😬", 46, 0, "#fff", "fx-up", 1200)],
    wave:        ["success", "m-wave .45s ease-in-out 4", 1900, () => spark("👋", 46, 4, "#fff", "fx-up", 1300)],
    jump:        ["success", "m-jump .5s ease-out 2", 1100, () => spark("✦", 30, 34, "#ffe46b", "fx-fall", 700)],
    blink:       ["idle", "th-blink .35s linear 1", 400, null],
    spin:        ["working", "m-spin .7s ease-in-out 1", 900, () => spark("✦", 46, 6, "#c9b6ff", "fx-up", 800)],
    fly:         ["searching", "m-fly .6s ease-in-out 3", 1800, () => spark("~", 4, 26, "#c9b6ff", "fx-fall", 800, -6)],
    "thunder shock": ["error", "m-flash .9s linear 2, m-jolt .3s ease 3", 2000, () => { for (let i = 0; i < 4; i++) setTimeout(() => { spark("⚡", 6 + Math.random() * 46, -6, "#ffe46b", "fx-bolt", 500); spark("ϟ", 10 + Math.random() * 40, 0, "#b06bff", "fx-bolt", 500); }, i * 220); setTimeout(() => { for (let i = 0; i < 5; i++) spark("·", 14 + i * 8, 28, "#ffe46b", "fx-fall", 900, (i - 2) * 3); }, 1000); }],
    "cloud form":  ["sleeping", "m-cloud 1.2s ease-in-out 2", 2500, () => { spark("☁", 6, 6, "#ddd", "fx-up", 2000, -4); spark("☁", 44, 8, "#ddd", "fx-up", 2000, 4); }],
    "idea burst":  ["thinking", "m-jump .4s ease-out 1, m-flash .6s linear 1", 2000, () => { spark("💡", 26, -8, "#ffe46b", "fx-up", 1500); for (let i = 0; i < 6; i++) spark("✦", 30, 6, "#ffe46b", "fx-up", 900, (i - 3) * 6); }],
    "chaos mode":  ["working", "m-chaos .8s linear 4, m-shake .1s linear 30", 3200, () => { for (let i = 0; i < 6; i++) setTimeout(() => spark(["⚡", "💢", "✦", "ϟ"][i % 4], Math.random() * 54, Math.random() * 20, "#ff6bf0", "fx-up", 700, (Math.random() - .5) * 16), i * 400); }],
  };
  const ALIAS = { "thundershock": "thunder shock", "shock": "thunder shock", "lightning": "thunder shock", "cloud": "cloud form", "idea": "idea burst", "chaos": "chaos mode", "angry": "yelling" };
  let busy = 0, last = 0;
  function play(name) {
    name = String(name || "").toLowerCase().trim(); name = ALIAS[name] || name; const m = M[name]; if (!m) return false;
    clearTimeout(busy); last = Date.now(); const prev = pet.getAttribute("state") === "sleeping" ? "sleeping" : "idle";
    const keep = lbl.textContent; orb.dataset.move = name; lbl.textContent = "ThundR · " + name; pet.setAttribute("state", m[0]);
    const base = getComputedStyle(pet).animation; pet.style.animation = (m[1] + ", " + "th-bob 2.4s ease-in-out infinite");
    if (m[3]) m[3]();
    busy = setTimeout(() => { delete orb.dataset.move; pet.style.animation = ""; pet.setAttribute("state", prev); lbl.textContent = prev === "sleeping" ? "ThundR · sleeping" : (orb.classList.contains("awake") ? "ThundR · awake" : "ThundR · idle"); }, m[2]);
    return true;
  }
  // gesture reactions (click = poke/shocked, drag = fly, hold = facepalm, dblclick = wave)
  let seen = 0;
  setInterval(() => { const g = O.state().gestures; if (g.length === seen) return; const k = g[g.length - 1]; seen = g.length;
    if (k === "click") setTimeout(() => play(Math.random() < .5 ? "poke" : "shocked"), 1600); else if (k === "drag") play("fly"); else if (k === "hold") play("facepalm"); else if (k === "dblclick") play("wave"); }, 150);
  // idle auto-moods every 20–45 s (awake, chat closed, not sleeping)
  const IDLE = ["blink", "mischievous", "smug", "wave", "jump", "spin", "nervous", "blink", "idea burst", "tired"];
  (function auto() { setTimeout(() => { const s = O.state(); if (!s.open && pet.getAttribute("state") === "idle" && Date.now() - last > 15000) play(IDLE[Math.floor(Math.random() * IDLE.length)]); auto(); }, 20000 + Math.random() * 25000); })();
  // chat: commands trigger moves locally; replies trigger ability effects
  const inp = document.querySelector("#th-chat input");
  if (inp) inp.addEventListener("keydown", (e) => { if (e.key !== "Enter") return; const t = inp.value.trim().toLowerCase().replace(/^(do|be|use|show)\s+/, ""); if (M[ALIAS[t] || t]) play(t); }, true);
  const prevReply = window.THUNDR_REPLY;
  window.THUNDR_REPLY = (id, body) => { try { const r = typeof body === "string" ? JSON.parse(body) : body; const txt = String((r && (r.reply || r.output || r.error)) || "");
      if (id < 900000 && !(r && r.anim)) { if (/^Refused/.test(txt)) play("yelling"); else if (r && r.ok === false) play("shocked"); else if (/wallet|balance|SOL/i.test(txt)) play("thunder shock"); else if (/via bot|DRAGOSKUL/i.test(txt) || (r && /bot/.test(r.via || ""))) play("idea burst"); else if (/heal/i.test(txt)) play("cloud form"); }
    } catch (e) {} return prevReply(id, body); };
  window.THUNDR_MOVES = { play, list: () => Object.keys(M), version: "1.2" };
})();

/* ThundR STATUS STRIPS + CROSS-APP MERGE (2026-10-23 pt102u) · egg/float web only
   - Tiny progress strips under the float label AND inside #th-chat (wallet/casket/scan/signing/mcr)
   - Chat: status bar | show bars | hide bars | hide | status bar <lane> <0-100|pulse|off>
   - Presence lock via MCR 127.0.0.1:8329 — only ONE ThundR visible across apps; float/control-room wins
   - Self-heal aware: keeps #thundr-strips / #th-chat-strips; still removes legacy #thundr-bar ghosts */
(function () {
  if (window.THUNDR_STRIPS_PRESENCE) return;
  const EP = "http://127.0.0.1:8329/v1/call/thundr_chat";
  const LANES = ["wallet", "casket", "scan", "signing", "mcr"];
  const KEY_VIS = "thundr.strips.visible";
  const KEY_VAL = "thundr.strips.values";
  const NATIVE = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float);
  const HOST = (document.title || location.hostname || "web").slice(0, 48);
  const ROLE = NATIVE ? "float" : (/mastercontrol|control.?room|mcr/i.test(location.href + HOST) ? "control-room" : "embed");
  const PRIO = ROLE === "float" ? 100 : ROLE === "control-room" ? 90 : 50;
  const IID = (ROLE + "-" + Math.random().toString(36).slice(2, 10) + "-" + Date.now().toString(36));
  let shown = localStorage.getItem(KEY_VIS) !== "0";
  let vals = {};
  try { vals = JSON.parse(localStorage.getItem(KEY_VAL) || "{}") || {}; } catch (e) { vals = {}; }
  LANES.forEach((k) => { if (vals[k] == null) vals[k] = k === "mcr" ? "pulse" : 0; });

  const css = document.createElement("style");
  css.id = "thundr-strips-css";
  css.textContent = `
#thundr-strips{display:none;flex-direction:column;gap:1px;width:52px;margin-top:1px;pointer-events:none}
#thundr-strips.on{display:flex}
#thundr-strips .s{height:2px;border-radius:1px;background:#1a1430;overflow:hidden;position:relative}
#thundr-strips .s i{display:block;height:100%;width:0;background:linear-gradient(90deg,#6b4fd8,#ffe46b);border-radius:1px}
#thundr-strips .s[data-v="pulse"] i{width:100%;animation:th-strip-pulse 1.2s ease-in-out infinite;opacity:.85}
#thundr-strips .s[data-lane="wallet"] i{background:linear-gradient(90deg,#2b8,#7dffb0)}
#thundr-strips .s[data-lane="casket"] i{background:linear-gradient(90deg,#6b4fd8,#c9b6ff)}
#thundr-strips .s[data-lane="scan"] i{background:linear-gradient(90deg,#1a6,#4df)}
#thundr-strips .s[data-lane="signing"] i{background:linear-gradient(90deg,#a40,#ffe46b)}
#thundr-strips .s[data-lane="mcr"] i{background:linear-gradient(90deg,#6b4fd8,#fff)}
#th-chat-strips{display:none;flex-direction:column;gap:3px;padding:4px 8px;border-bottom:1px solid #3a2d70}
#th-chat-strips.on{display:flex}
#th-chat-strips .s{display:flex;align-items:center;gap:6px;font:600 9px ui-monospace,Menlo,monospace;color:#c9b6ff}
#th-chat-strips .s b{flex:0 0 52px;font-weight:700;color:#ffe46b;text-transform:uppercase;letter-spacing:.02em}
#th-chat-strips .s .t{flex:1;height:5px;border-radius:3px;background:#1a1430;overflow:hidden}
#th-chat-strips .s .t i{display:block;height:100%;width:0;background:linear-gradient(90deg,#6b4fd8,#ffe46b)}
#th-chat-strips .s[data-v="pulse"] .t i{width:40%;animation:th-strip-slide 1.1s linear infinite}
#th-chat-strips .s em{flex:0 0 28px;text-align:right;color:#888;font-style:normal}
@keyframes th-strip-pulse{0%,100%{opacity:.35}50%{opacity:1}}
@keyframes th-strip-slide{0%{transform:translateX(-120%)}100%{transform:translateX(280%)}}
#thundr-pin.th-orb.th-yielded{display:none!important}
#th-chat.th-yielded{display:none!important}`;
  document.head.appendChild(css);

  function ensureDom() {
    const orb = document.getElementById("thundr-pin");
    if (!orb) return null;
    let strips = document.getElementById("thundr-strips");
    if (!strips) {
      strips = document.createElement("div");
      strips.id = "thundr-strips";
      strips.dataset.thundrOk = "1";
      strips.innerHTML = LANES.map((k) => `<div class="s" data-lane="${k}"><i></i></div>`).join("");
      const lbl = orb.querySelector(".lbl");
      if (lbl && lbl.parentNode === orb) orb.insertBefore(strips, lbl.nextSibling);
      else orb.appendChild(strips);
    }
    const chat = document.getElementById("th-chat");
    let cstrips = document.getElementById("th-chat-strips");
    if (chat && !cstrips) {
      cstrips = document.createElement("div");
      cstrips.id = "th-chat-strips";
      cstrips.dataset.thundrOk = "1";
      cstrips.innerHTML = LANES.map((k) => `<div class="s" data-lane="${k}"><b>${k}</b><div class="t"><i></i></div><em>0</em></div>`).join("");
      const hd = chat.querySelector(".hd");
      if (hd) hd.insertAdjacentElement("afterend", cstrips);
      else chat.prepend(cstrips);
    }
    return { orb, strips, chat, cstrips: document.getElementById("th-chat-strips") };
  }

  function paint() {
    const d = ensureDom(); if (!d) return;
    d.strips.classList.toggle("on", !!shown);
    if (d.cstrips) d.cstrips.classList.toggle("on", !!shown);
    LANES.forEach((k) => {
      const v = vals[k];
      const row = d.strips.querySelector(`[data-lane="${k}"]`);
      if (row) {
        row.dataset.v = v === "pulse" ? "pulse" : "n";
        const i = row.querySelector("i");
        if (v === "pulse") i.style.width = "100%";
        else i.style.width = Math.max(0, Math.min(100, Number(v) || 0)) + "%";
        row.style.opacity = (!v || v === 0 || v === "0") ? ".25" : "1";
      }
      if (d.cstrips) {
        const cr = d.cstrips.querySelector(`[data-lane="${k}"]`);
        if (!cr) return;
        cr.dataset.v = v === "pulse" ? "pulse" : "n";
        const i = cr.querySelector("i");
        const em = cr.querySelector("em");
        if (v === "pulse") { i.style.width = "40%"; em.textContent = "…"; }
        else { const n = Math.max(0, Math.min(100, Number(v) || 0)); i.style.width = n + "%"; em.textContent = String(n); }
      }
    });
    try { localStorage.setItem(KEY_VIS, shown ? "1" : "0"); localStorage.setItem(KEY_VAL, JSON.stringify(vals)); } catch (e) {}
  }

  function setVisible(on) { shown = !!on; paint(); return shown ? "status bars ON (wallet/casket/scan/signing/mcr)" : "status bars hidden"; }
  function setLane(lane, raw) {
    const k = String(lane || "").toLowerCase();
    if (!LANES.includes(k)) return "unknown lane · try: " + LANES.join("|");
    const t = String(raw == null ? "" : raw).trim().toLowerCase();
    if (t === "off" || t === "hide" || t === "clear") vals[k] = 0;
    else if (t === "pulse" || t === "…" || t === "indeterminate" || t === "working") vals[k] = "pulse";
    else if (t === "" || t === "on") vals[k] = vals[k] && vals[k] !== 0 ? vals[k] : "pulse";
    else vals[k] = Math.max(0, Math.min(100, parseInt(t, 10) || 0));
    shown = true; paint();
    return "status bar " + k + " → " + vals[k];
  }

  // --- chat command hook (wrap THUNDR_IOS.chat and THUNDR_ORB.ask path) ---
  function handleCmd(text) {
    const low = String(text || "").trim().toLowerCase();
    if (/^\/?(rkrypt|rgen)\b/.test(low)) return new Promise((res) => { const go = () => window.RKRYPT.cmd(String(text).trim()).then((r) => res({ ok: true, via: "rkrypt", reply: "RKRYPT · " + (r ? (r.text || JSON.stringify(r.json)) : "unknown command") })).catch((er) => res({ ok: false, via: "rkrypt", reply: "RKRYPT · " + er.message })); if (window.RKRYPT) return go(); const s = document.createElement("script"); s.src = "rkrypt/rkrypt.rzl.js"; s.onload = go; s.onerror = () => res({ ok: false, via: "rkrypt", reply: "RKRYPT · rkrypt/rkrypt.rzl.js not found" }); document.head.appendChild(s); }); // RKRYPT.rdos hook 20261025
    if (/^(status bars?|show bars?|bars on)$/.test(low)) return { ok: true, via: "strips", reply: "ThundR · " + setVisible(true) };
    if (/^(hide bars?|bars off|hide status bars?)$/.test(low)) return { ok: true, via: "strips", reply: "ThundR · " + setVisible(false) };
    if (/^hide$/.test(low)) return { ok: true, via: "strips", reply: "ThundR · " + setVisible(false) };
    let m = low.match(/^status bars?\s+(\w+)(?:\s+(.+))?$/);
    if (m) return { ok: true, via: "strips", reply: "ThundR · " + setLane(m[1], m[2]) };
    if (/^(presence|who has thundr|thundr presence)$/.test(low)) return { ok: true, via: "presence", reply: "ThundR · presence " + (window.THUNDR_STRIPS_PRESENCE && window.THUNDR_STRIPS_PRESENCE.snapshot ? JSON.stringify(window.THUNDR_STRIPS_PRESENCE.snapshot()) : "local-only") };
    return null;
  }

  const prevIOS = window.THUNDR_IOS && window.THUNDR_IOS.chat;
  if (window.THUNDR_IOS && prevIOS) {
    window.THUNDR_IOS.chat = function (text) {
      const hit = handleCmd(text); if (hit) return hit;
      return prevIOS(text);
    };
  } else {
    window.THUNDR_IOS = window.THUNDR_IOS || {};
    const base = window.THUNDR_IOS.chat;
    window.THUNDR_IOS.chat = function (text) {
      const hit = handleCmd(text); if (hit) return hit;
      return base ? base(text) : { ok: true, via: "local", reply: "ThundR heard you." };
    };
  }

  // --- presence / merge ---
  let yielded = false, holder = null, hbTimer = null;
  function postPresence(text) {
    if (NATIVE) {
      return new Promise((res) => {
        const id = "p" + Math.random().toString(36).slice(2, 8);
        function on(ev) { if (!ev.data || ev.data.id !== id) return; window.removeEventListener("message", on); res(ev.data.result || {}); }
        window.addEventListener("message", on);
        try { window.webkit.messageHandlers.float.postMessage({ op: "call", id, tool: "thundr_chat", text }); } catch (e) { res({ ok: false, offline: true }); }
        setTimeout(() => { window.removeEventListener("message", on); res({ ok: false, offline: true }); }, 1200);
      });
    }
    return fetch(EP, { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text }) })
      .then((r) => r.json()).catch(() => ({ ok: false, offline: true }));
  }
  function applyYield(on, why) {
    yielded = !!on;
    const orb = document.getElementById("thundr-pin");
    const chat = document.getElementById("th-chat");
    if (orb) orb.classList.toggle("th-yielded", yielded);
    if (chat) chat.classList.toggle("th-yielded", yielded);
    if (yielded && window.THUNDR_ORB && window.THUNDR_ORB.openChat) try { window.THUNDR_ORB.openChat(false); } catch (e) {}
    const lbl = orb && orb.querySelector(".lbl");
    if (lbl && !yielded) { /* leave label to anim/heal */ }
    return why;
  }
  async function claim() {
    const r = await postPresence("thundr presence claim " + IID + " " + PRIO + " " + ROLE + " " + HOST.replace(/\s+/g, "_"));
    if (r && r.offline) { applyYield(false, "mcr-offline-local"); return; }
    const reply = String((r && (r.reply || r.output)) || "");
    let j = null;
    try { j = JSON.parse(reply.replace(/^ThundR · presence\s*/, "")); } catch (e) {
      const m = reply.match(/\{.*\}/); if (m) try { j = JSON.parse(m[0]); } catch (e2) {}
    }
    if (!j && r && typeof r === "object" && r.holder) j = r;
    holder = j;
    if (j && j.holder && j.holder !== IID && (j.prio || 0) >= PRIO) applyYield(true, "yield→" + j.role + ":" + j.holder);
    else applyYield(false, "holder");
  }
  async function heartbeat() {
    const r = await postPresence("thundr presence beat " + IID + " " + PRIO + " " + ROLE);
    if (r && r.offline) return;
    const reply = String((r && (r.reply || r.output)) || "");
    let j = null;
    try { j = JSON.parse(reply.replace(/^ThundR · presence\s*/, "")); } catch (e) { const m = reply.match(/\{.*\}/); if (m) try { j = JSON.parse(m[0]); } catch (e2) {} }
    if (j) {
      holder = j;
      if (j.holder && j.holder !== IID && (j.prio || 0) > PRIO) applyYield(true, "yield");
      else if (j.holder === IID || (j.prio || 0) < PRIO) applyYield(false, "keep");
    }
  }
  function yieldNow() { postPresence("thundr presence yield " + IID); applyYield(true, "yielded"); }

  // self-heal: stop killing our strips; still remove legacy ghosts
  const wrapHeal = () => {
    const H = window.THUNDR_HEAL; if (!H || H._stripsWrapped) return;
    const prev = H.check.bind(H);
    H.check = function (why) {
      const out = prev(why);
      // re-show strips if heal hid nothing important — ensure DOM + paint
      paint();
      const s = document.getElementById("thundr-strips");
      const c = document.getElementById("th-chat-strips");
      if (s) { s.hidden = false; s.style.removeProperty("display"); }
      if (c) { c.hidden = false; c.style.removeProperty("display"); }
      // hide only if user turned bars off
      if (!shown) {
        if (s) s.classList.remove("on");
        if (c) c.classList.remove("on");
      }
      return out;
    };
    H._stripsWrapped = true;
  };

  // patch heal list: don't treat thundr-strips as ghost — monkeypatch after heal loads
  const hideGhost = () => {
    // Override query that heal uses by renaming conflict: ensure #thundr-bar stays gone
    document.querySelectorAll("#thundr-bar").forEach((e) => e.remove());
  };

  function boot() {
    ensureDom(); paint(); hideGhost(); wrapHeal();
    claim();
    if (hbTimer) clearInterval(hbTimer);
    hbTimer = setInterval(() => { heartbeat(); wrapHeal(); paint(); }, 3000);
    window.addEventListener("pagehide", yieldNow);
    window.addEventListener("beforeunload", yieldNow);
  }
  if (document.getElementById("thundr-pin")) boot();
  else {
    const ob = new MutationObserver(() => { if (document.getElementById("thundr-pin")) { ob.disconnect(); boot(); } });
    ob.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(boot, 1500);
  }

  window.THUNDR_STRIPS_PRESENCE = {
    version: "1.0.0",
    setVisible, setLane, handleCmd, claim, yieldNow,
    snapshot: () => ({ iid: IID, role: ROLE, prio: PRIO, yielded, holder, shown, vals: { ...vals } })
  };
})();


/* ThundR STATUS LIVE BAR v3 (2026-10-24 pt51u) · under the floating sprite: rounded 190×8 % bar (purple→yellow, smooth)
   + % number, then Grok-style activity line "••• <present-tense real step>" (crossfade) + dimmed previous line.
   Opens on STATUS/status//status, `thundr status --show`, the global one-word watch, AND automatically whenever any real
   progress source is running (polls every 4 s while closed). Real sources only. 100% ✓ done → collapses to bare sprite. */
(function () {
  if (window.THUNDR_STATUS) return;
  const O = window.THUNDR_ORB, orb = document.getElementById("thundr-pin"), chat = document.getElementById("th-chat"); if (!O || !orb) return;
  const inp = chat && chat.querySelector("input");
  const NATIVE = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float);
  const css = document.createElement("style");
  css.textContent = "#th-mini{position:fixed;z-index:2147483602;width:226px;display:none;padding:3px 7px;box-sizing:border-box;border-radius:9px;background:rgba(18,10,40,.92);border:1px solid #8a5cff;color:#e9dcff;font:10px/12px -apple-system,system-ui;pointer-events:none}" +
    "#th-mini.on{display:block!important}#th-mini .r{display:flex;align-items:center;gap:6px;height:10px}" +
    "#th-mini .tr{flex:1;height:8px;border-radius:4px;background:#2a1a4a;overflow:hidden;box-shadow:inset 0 0 0 1px #3d2a70}" +
    "#th-mini .fl{height:100%;width:0;border-radius:4px;background:linear-gradient(90deg,#8a5cff,#ffd23f);transition:width .8s ease}" +
    "#th-mini.run .fl{background-image:linear-gradient(90deg,#8a5cff,#c08bff,#ffd23f,#c08bff,#8a5cff);background-size:300% 100%;animation:thm 2s linear infinite}@keyframes thm{to{background-position:-300% 0}}" +
    "#th-mini .pc{font:700 11px system-ui;color:#ffe46b;white-space:nowrap}" +
    "#th-mini .ac{display:flex;align-items:center;gap:5px;height:13px;margin-top:1px}#th-mini .dots{display:flex;gap:2px}" +
    "#th-mini .dots i{width:4px;height:4px;border-radius:50%;background:#c9b6ff;animation:thd 1.2s infinite ease-in-out}#th-mini .dots i:nth-child(2){animation-delay:.2s}#th-mini .dots i:nth-child(3){animation-delay:.4s}" +
    "@keyframes thd{0%,80%,100%{opacity:.25;transform:scale(.8)}40%{opacity:1;transform:scale(1.15)}}#th-mini:not(.run) .dots i{animation:none;opacity:.5}" +
    "#th-mini .ph{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff;transition:opacity .35s}#th-mini .ph.fade{opacity:0}" +
    "#th-mini .jr{display:flex;gap:4px;height:12px;line-height:12px;font-size:9px;white-space:nowrap}#th-mini .jr b{color:#ffe46b;font-weight:700}#th-mini .jr .jn{color:#fff;max-width:70px;overflow:hidden;text-overflow:ellipsis}#th-mini .jr .js{flex:1;overflow:hidden;text-overflow:ellipsis;opacity:.85}#th-mini .jr .ja{opacity:.55}" +
    "#th-mini .x{position:absolute;right:2px;top:0;pointer-events:auto;cursor:pointer;color:#c9b6ff;font:10px system-ui;padding:0 2px}#th-mini .x:hover{color:#ffe46b}#th-mini{position:fixed}" +
    "#th-mini .pv{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;opacity:.5;height:11px;line-height:11px;font-size:9px}";
  document.head.appendChild(css);
  const box = document.createElement("div"); box.id = "th-mini";
  box.innerHTML = '<div class="r"><div class="tr"><div class="fl"></div></div><div class="pc">…</div></div><div class="ac"><span class="dots"><i></i><i></i><i></i></span><span class="ph"></span></div><div class="pv"></div><div class="jl"></div><span class="x" title="close (Esc)">✕</span>';
  document.body.appendChild(box);
  const fl = box.querySelector(".fl"), pc = box.querySelector(".pc"), ph = box.querySelector(".ph"), pv = box.querySelector(".pv"), lbl = orb.querySelector(".lbl"), jl = box.querySelector(".jl");
  box.querySelector(".x").addEventListener("click", (e) => { e.stopPropagation(); stop(0); });
  function place() { const ci = inp && inp.offsetParent && chat && !chat.hidden ? inp : null; const r = (ci || orb).getBoundingClientRect(); box.style.left = Math.max(2, r.left) + "px"; box.style.top = (r.bottom + 1) + "px"; }
  function poll() {
    if (NATIVE) return new Promise((res) => { const id = 800000 + Math.floor(Math.random() * 99999), prev = window.THUNDR_REPLY;
      const t = setTimeout(() => { window.THUNDR_REPLY = prev; res(null); }, 8000);
      window.THUNDR_REPLY = (i, b) => { if (i === id) { clearTimeout(t); window.THUNDR_REPLY = prev; res(b); } else prev && prev(i, b); };
      try { window.webkit.messageHandlers.float.postMessage({ op: "call", id, tool: "thundr_chat", text: "status-live" }); } catch (e) { res(null); } });
    return fetch("http://127.0.0.1:8329/v1/call/thundr_chat", { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text: "status-live" }) }).then((r) => r.json()).catch(() => null);
  }
  // present-tense phrase from REAL sources only
  const VERB = { "build": "Building", "compiling Swift": "Compiling Swift", "linking": "Linking", "code signing": "Signing app", "device push/install": "Installing on iPhone",
    "egg push": "Pushing egg", "Face ID sign request": "Waiting for Face ID sign", "copying": "Copying source", "git push": "Pushing to RFORGE", "cleaning": "Cleaning DerivedData" };
  function phrase(L) {
    if (!L.running) return null;
    const t = (L.tasks || [])[0]; if (!t) return null;
    if (t.pid === 0 && t.detail) { const m = t.detail.match(/^[^:]*:\s*(.*)$/); const txt = (m ? m[1] : t.detail).trim(); return (t.what ? t.what + " · " : "") + txt.replace(/\.?$/, "…"); }
    const v = VERB[t.what] || (t.what.charAt(0).toUpperCase() + t.what.slice(1));
    return v + (t.detail ? " · " + t.detail : "") + "…";
  }
  let cur = "";
  function setPhrase(p) {
    if (!p || p === cur) return;
    if (cur) pv.textContent = cur; cur = p;
    ph.classList.add("fade"); setTimeout(() => { ph.textContent = p; ph.classList.remove("fade"); }, 300);
  }
  let timer = null, sawRun = false, oldLbl = null, active = false, auto = false;
  function setWin(open) { if (NATIVE) try { window.webkit.messageHandlers.float.postMessage({ op: "status", open }); } catch (e) {} }
  function paint(s) {
    if (!s || !s.live) { pc.textContent = "MCR…"; setPhrase("Reconnecting to MCR 127.0.0.1:8329…"); return; }
    const L = s.live, run = !!L.running, h = L.health || {};
    box.classList.toggle("run", run);
    const p = run ? Math.max(1, Math.min(99, L.pct | 0)) : 100; fl.style.width = p + "%";
    pc.textContent = run ? p + "%" : (sawRun ? "100% ✓ done" : "idle ✓");
    if (run) setPhrase(phrase(L) || L.headline);
    else setPhrase(sawRun ? "Done · nothing left running · apps " + h.ok + "/" + h.total + " up" : "Nothing running" + (L.last ? " · last: " + L.last.msg : ""));
    const J = (L.jobs || []), esc = (x) => String(x == null ? "" : x).replace(/[&<>"]/g, (c) => "&#" + c.charCodeAt(0) + ";"), ago = (n) => n < 60 ? n + " s ago" : Math.round(n / 60) + " min ago";
    const show = NATIVE ? J.slice(0, 1) : J.slice(0, 6);
    jl.innerHTML = show.map((j) => '<div class="jr"><span class="jn">' + esc(j.job) + '</span>·<span class="js">' + esc(j.step) + '</span>·<b>' + (j.pct | 0) + '%</b>·<span class="ja">updated ' + ago(j.age | 0) + '</span></div>').join("") + (J.length > show.length ? '<div class="jr ja">+' + (J.length - show.length) + ' more</div>' : "");
    if (lbl) lbl.textContent = run ? "ThundR · " + p + "%" : (oldLbl || "ThundR · idle");
  }
  async function tick() {
    const s = await poll(); paint(s); place();
    const run = !!(s && s.live && s.live.running); if (run) sawRun = true;
    if (s && s.live && !run) { stop(sawRun ? 5000 : 9000); return; }
    timer = setTimeout(tick, 2000);
  }
  function stop(after) { clearTimeout(timer); timer = setTimeout(() => { box.classList.remove("on"); active = false; if (lbl) lbl.textContent = oldLbl || "ThundR · idle"; setWin(false); }, after || 0); }
  function start(src) {
    clearTimeout(timer); if (!active) { sawRun = false; cur = ""; ph.textContent = ""; pv.textContent = ""; if (lbl) oldLbl = /\d+%/.test(lbl.textContent) ? "ThundR · idle" : lbl.textContent; }
    active = true; auto = src === "auto";
    if (src !== "auto" && O.state && O.state().open) O.openChat(false); /* 2026-10-29 repair: auto live-status no longer collapses an open chat */
    setWin(true); place(); box.classList.add("on"); tick();
    return { ok: true, via: "livestatus", reply: "ThundR · live status under the sprite" };
  }
  // auto-open whenever a real progress source is running
  setInterval(async () => { if (active) return; const s = await poll(); if (s && s.live && s.live.running && !active) start("auto"); }, 4000);
  const RX = /^\s*\/?status\s*$/i, OFF = /^\s*\/?status\s+off\s*$/i;
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && active) { stop(0); } }, true);
  if (inp) inp.addEventListener("keydown", (e) => { if (e.key === "Enter" && OFF.test(inp.value)) { e.preventDefault(); e.stopImmediatePropagation(); inp.value = ""; stop(0); return; } if (e.key === "Enter" && RX.test(inp.value)) { e.preventDefault(); e.stopImmediatePropagation(); inp.value = ""; start("typed"); } }, true);
  const prevIOS = window.THUNDR_IOS && window.THUNDR_IOS.chat;
  if (prevIOS) window.THUNDR_IOS.chat = function (t) { if (OFF.test(String(t || ""))) { stop(0); return { ok: true, via: "livestatus", reply: "ThundR · status closed" }; } if (RX.test(String(t || ""))) return start("chat"); return prevIOS(t); };
  setInterval(() => { if (active) { place(); if (getComputedStyle(box).display === "none") box.classList.add("on"); } }, 200);
  window.THUNDR_STATUS = { start, stop, active: () => active, version: "3.0.0" };
})();

/* ThundR LINK + MERGE v3 (2026-10-24 pt51u) · linked ThundRs find each other over the local MCR link (127.0.0.1:8329, never off-box):
   each instance posts "presence <id> <host> <state>" every 15 s; status-live returns live peers. When two are open they fly together,
   high-five (success frame + ✋⚡ spark), and the non-survivor absorbs into the survivor (float wins, else lowest id). The absorbed
   one stays linked: it keeps posting presence/progress, and re-emerges if the survivor goes away. Merge logs a real
   "ThundR merged: X + Y" event (selfheal.log → ticker). In-page duplicate sprites get the same high-five + absorb instead of a silent delete. */
(function () {
  if (window.THUNDR_LINK) return;
  const O = window.THUNDR_ORB, orb = document.getElementById("thundr-pin"); if (!O || !orb) return;
  const NATIVE = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float);
  const HOST = NATIVE ? "float" : (location.host || "page").replace(/\s/g, "");
  const ID = (NATIVE ? "a-" : "b-") + HOST.replace(/[^a-z0-9.:-]/gi, "") + "-" + Math.random().toString(36).slice(2, 7);
  const css = document.createElement("style");
  css.textContent = "@keyframes thl-hi{0%{transform:translate(0,0)}35%{transform:translate(var(--dx),-6px) rotate(-12deg)}50%{transform:translate(var(--dx),-6px) rotate(10deg) scale(1.15)}100%{transform:translate(0,0)}}" +
    "@keyframes thl-ab{0%{transform:translate(0,0) scale(1);opacity:1}40%{transform:translate(var(--dx),-6px) rotate(10deg)}100%{transform:translate(var(--dx),0) scale(.1);opacity:0}}" +
    ".thl-hi{animation:thl-hi 1.4s ease-in-out}.thl-ab{animation:thl-ab 1.4s ease-in forwards}" +
    ".thl-sp{position:fixed;z-index:2147483603;font:16px system-ui;pointer-events:none;animation:thl-sp 1s ease-out forwards}@keyframes thl-sp{0%{opacity:0;transform:scale(.4)}30%{opacity:1;transform:scale(1.4)}100%{opacity:0;transform:scale(1) translateY(-14px)}}";
  document.head.appendChild(css);
  function send(text) {
    if (NATIVE) { try { window.webkit.messageHandlers.float.postMessage({ op: "call", id: 900000 + Math.floor(Math.random() * 99999), tool: "thundr_chat", text }); } catch (e) {} return; }
    fetch("http://127.0.0.1:8329/v1/call/thundr_chat", { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text }) }).catch(() => {});
  }
  function spark(el) { const r = el.getBoundingClientRect(); const s = document.createElement("div"); s.className = "thl-sp"; s.textContent = "✋⚡"; s.style.left = (r.left + r.width / 2 - 12) + "px"; s.style.top = (r.top - 4) + "px"; document.body.appendChild(s); setTimeout(() => s.remove(), 1100); }
  function frame(pet, st, ms) { if (!pet) return; const old = pet.getAttribute("state") || "idle"; pet.setAttribute("state", st); setTimeout(() => pet.setAttribute("state", old), ms); }
  const pet = () => orb.querySelector("thundr-live");
  function highFive(dx) { if (window.THUNDR_HF) { window.THUNDR_HF(); window.THUNDR_SUPER && setTimeout(() => window.THUNDR_SUPER.charge(), 1500); return; } const p = pet(); if (!p) return; p.style.setProperty("--dx", dx + "px"); p.classList.remove("thl-hi"); void p.offsetWidth; p.classList.add("thl-hi"); frame(p, "success", 1500); setTimeout(() => spark(p), 500); setTimeout(() => p.classList.remove("thl-hi"), 1500); }
  let absorbed = false;
  function absorb(into) { if (absorbed) return; absorbed = true; const p = pet(); if (window.THUNDR_HF) window.THUNDR_HF(); else if (p) { p.style.setProperty("--dx", "16px"); frame(p, "success", 1400); p.classList.add("thl-ab"); setTimeout(() => spark(p), 500); }
    setTimeout(() => { orb.style.setProperty("visibility", "hidden", "important"); const m = document.getElementById("th-mini"); if (m) m.style.setProperty("visibility", "hidden", "important"); }, 1400); }
  function emerge() { if (!absorbed) return; absorbed = false; orb.style.removeProperty("visibility"); const m = document.getElementById("th-mini"); if (m) m.style.removeProperty("visibility"); const p = pet(); if (p) { p.classList.remove("thl-ab"); frame(p, "hatch", 1200); } }
  // in-page duplicate: high-five + absorb instead of silent delete (called by self-heal/dedupe before removal)
  window.THUNDR_MERGE_DUP = function (el) { try { highFive(10); const r = el.getBoundingClientRect && el.getBoundingClientRect(); send("selfheal-log: ThundR merged: " + HOST + " + in-page duplicate (absorbed)"); } catch (e) {} };
  const merged = {};
  function onPeers(list) {
    const others = (list || []).filter((x) => x.id !== ID); if (!others.length) { emerge(); return; }
    const all = list.some((x) => x.id === ID) ? list : list.concat([{ id: ID, host: HOST }]);
    const survivor = all.slice().sort((a, b) => a.id < b.id ? -1 : 1)[0];
    if (survivor.id === ID) { emerge(); if (window.THUNDR_SUPER && window.THUNDR_SUPER.on()) window.THUNDR_SUPER.charge(600000); others.forEach((o) => { if (!merged[o.id]) { merged[o.id] = 1; highFive(-14); send("selfheal-log: ThundR merged: " + HOST + " + " + o.host + " (" + o.id + " absorbed, still linked)"); } }); }
    else absorb(survivor);
  }
  function beat() { send("selfheal-log: presence " + ID + " " + HOST + " " + (absorbed ? "absorbed" : "awake")); }
  async function look() {
    const s = await new Promise((res) => {
      if (!NATIVE) return fetch("http://127.0.0.1:8329/v1/call/thundr_chat", { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text: "status-live" }) }).then((r) => r.json()).then(res).catch(() => res(null));
      const id = 700000 + Math.floor(Math.random() * 99999), prev = window.THUNDR_REPLY; const t = setTimeout(() => { window.THUNDR_REPLY = prev; res(null); }, 8000);
      window.THUNDR_REPLY = (i, b) => { if (i === id) { clearTimeout(t); window.THUNDR_REPLY = prev; res(b); } else prev && prev(i, b); };
      try { window.webkit.messageHandlers.float.postMessage({ op: "call", id, tool: "thundr_chat", text: "status-live" }); } catch (e) { res(null); } });
    if (s && s.live) onPeers(s.live.peers);
  }
  beat(); setInterval(beat, 15000); setTimeout(look, 3000); setInterval(look, 10000);
  window.THUNDR_LINK = { id: ID, host: HOST, absorbed: () => absorbed, version: "3.0.0" };
})();

/* ThundR HIGH-FIVE + SUPERCHARGE v1 (2026-10-24 pt66u) · web-asset only (no app rebuild).
   THUNDR_HF(): plays atlas/thundr-96-highfive.webp (12 frames, 96x48 cells, drawn at 64x32 so it fits the 68x58 float window):
   two ThundRs fly in, palms meet, lightning burst, partner absorbs. After a merge THUNDR_SUPER.charge(ms) → SUPERCHARGED:
   brighter palette + electric aura (atlas/thundr-48-supercharged.webp crackle strip over idle), faster bob, sparks on every
   state change, big burst + pop on success/done. Lasts 10 min, refreshed while peers stay linked. "SUPERCHARGED" shows briefly
   in the activity line (or the sprite label when the bar is closed). No bars/badges/pills, no layout change, no pop-ups. */
(function () {
  if (window.THUNDR_SUPER) return;
  const orb = document.getElementById("thundr-pin"); if (!orb) return;
  const pet = () => orb.querySelector("thundr-live");
  const A = "thundr/atlas/";
  const css = document.createElement("style");
  css.textContent =
    "#th-hf{position:fixed;z-index:2147483604;width:64px;height:32px;pointer-events:none;background:url(" + A + "thundr-96-highfive.webp) 0 0/768px 32px no-repeat;image-rendering:pixelated;display:none}" +
    "#th-hf.on{display:block;animation:thhf 1.56s steps(12) forwards}@keyframes thhf{to{background-position:-768px 0}}" +
    "#th-sc{position:fixed;z-index:2147483601;pointer-events:none;image-rendering:pixelated;display:none;background:url(" + A + "thundr-48-supercharged.webp) 0 0/432px 36px no-repeat;width:36px;height:36px;animation:thsc .9s steps(12) infinite}@keyframes thsc{to{background-position:-432px 0}}" +
    "#thundr-pin.th-orb.th-super thundr-live{filter:brightness(1.25) saturate(1.5) drop-shadow(0 0 2px #78e6ff) drop-shadow(0 0 4px #ffe46b);animation:th-bob 1.1s ease-in-out infinite,th-blink 5.3s linear infinite!important}" +
    "#thundr-pin.th-orb.th-super.th-pop thundr-live{animation:thpop .5s ease-out 2,th-bob 1.1s ease-in-out infinite!important}@keyframes thpop{0%{transform:scale(.75)}40%{transform:scale(1.02) rotate(-8deg)}70%{transform:scale(.9) rotate(6deg)}100%{transform:scale(.75)}}" +
    ".th-zap{position:fixed;z-index:2147483605;pointer-events:none;font:11px system-ui;animation:thzap .8s ease-out forwards}@keyframes thzap{0%{opacity:0;transform:translate(0,0) scale(.4)}25%{opacity:1;transform:translate(calc(var(--x)*.4),calc(var(--y)*.4)) scale(1.3)}100%{opacity:0;transform:translate(var(--x),var(--y)) scale(.8)}}";
  document.head.appendChild(css);
  const hf = document.createElement("div"); hf.id = "th-hf"; document.body.appendChild(hf);
  const sc = document.createElement("div"); sc.id = "th-sc"; document.body.appendChild(sc);
  function rect() { const p = pet(); return (p || orb).getBoundingClientRect(); }
  function zap(n, big) {
    const r = rect(), cx = r.left + r.width / 2 - 5, cy = r.top + 14;
    for (let i = 0; i < n; i++) { const z = document.createElement("div"); z.className = "th-zap"; z.textContent = big && i % 3 === 0 ? "✨" : "⚡";
      const a = (i / n) * 6.283 + Math.random() * .4, d = (big ? 22 : 12) + Math.random() * 6;
      z.style.left = cx + "px"; z.style.top = cy + "px"; z.style.setProperty("--x", Math.cos(a) * d + "px"); z.style.setProperty("--y", Math.sin(a) * d * .7 + "px");
      z.style.animationDelay = (i * 25) + "ms"; document.body.appendChild(z); setTimeout(() => z.remove(), 1000 + i * 25); }
  }
  // high-five player
  window.THUNDR_HF = function () {
    const r = rect(), p = pet(); hf.style.left = Math.max(0, Math.min(innerWidth - 64, r.left + r.width / 2 - 32)) + "px"; hf.style.top = Math.max(0, r.top + 2) + "px";
    if (p) p.style.setProperty("opacity", "0", "important");
    hf.classList.remove("on"); void hf.offsetWidth; hf.classList.add("on");
    setTimeout(() => zap(8, true), 620);
    setTimeout(() => { hf.classList.remove("on"); if (p) p.style.removeProperty("opacity"); }, 1600);
  };
  let until = 0, scT = null;
  function say(t) {
    const S = window.THUNDR_STATUS, box = document.getElementById("th-mini"), ph = box && box.querySelector(".ph"), lbl = orb.querySelector(".lbl");
    if (S && S.active && S.active() && ph) { const o = ph.textContent; ph.textContent = t; setTimeout(() => { if (ph.textContent === t) ph.textContent = o; }, 4000); return; }
    if (lbl) { const o = lbl.textContent; lbl.textContent = t; setTimeout(() => { if (lbl.textContent === t) lbl.textContent = o; }, 4000); }
  }
  function on() { return Date.now() < until; }
  function paint() {
    const p = pet(), st = p && (p.getAttribute("state") || "idle"), live = on();
    orb.classList.toggle("th-super", live);
    if (live && st === "idle" && !hf.classList.contains("on") && getComputedStyle(orb).visibility !== "hidden") { const r = rect(); sc.style.display = "block"; sc.style.left = (r.left + r.width / 2 - 18) + "px"; sc.style.top = (r.top) + "px"; }
    else sc.style.display = "none";
    if (!live && until) { until = 0; say("ThundR · charge settled"); }
  }
  function charge(ms) { const was = on(); until = Math.max(until, Date.now() + (ms || 600000)); if (!was) { say("⚡ SUPERCHARGED ⚡"); zap(10, true); } paint();
    if (!was && window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float) try { window.webkit.messageHandlers.float.postMessage({ op: "call", id: 910000 + Math.floor(Math.random() * 9999), tool: "thundr_chat", text: "selfheal-log: ThundR SUPERCHARGED (" + Math.round((until - Date.now()) / 60000) + " min)" }); } catch (e) {} }
  // amplified reactions while charged
  let last = "";
  new MutationObserver(() => { const p = pet(); const st = p && p.getAttribute("state"); if (!on() || st === last) { last = st; paint(); return; } last = st;
    if (st === "success" || st === "hatch") { orb.classList.remove("th-pop"); void orb.offsetWidth; orb.classList.add("th-pop"); setTimeout(() => orb.classList.remove("th-pop"), 1000); zap(12, true); }
    else if (st === "error") zap(4, false); else if (st && st !== "idle") zap(5, false);
    paint(); }).observe(orb, { subtree: true, attributes: true, attributeFilter: ["state"] });
  // done in the live bar → big burst
  let wasDone = false; setInterval(() => { paint(); const pc = document.querySelector("#th-mini .pc"); const d = !!(pc && /done/.test(pc.textContent)); if (d && !wasDone && on()) { zap(14, true); orb.classList.add("th-pop"); setTimeout(() => orb.classList.remove("th-pop"), 1000); } wasDone = d; }, 400);
  window.THUNDR_SUPER = { charge, on, zap, version: "1.0.0" };
})();

// 2026-10-30 ThundR progress monitor: one-line jobs summary in the live-status bar (read-only; never opens/closes chat or the bar)
(function () {
  function go() { const box = document.getElementById("th-mini"); if (!box) return false;
    let jb = box.querySelector(".jb"); if (!jb) { jb = document.createElement("div"); jb.className = "jb"; jb.style.cssText = "font-size:9px;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"; box.insertBefore(jb, box.querySelector(".x")); }
    const upd = () => fetch("http://127.0.0.1:8329/v1/jobs").then((r) => r.json()).then((j) => { jb.textContent = "jobs · " + (j.summary || "?"); }).catch(() => {});
    upd(); setInterval(upd, 15000); return true; }
  if (!go()) { let n = 0; const iv = setInterval(() => { if (go() || ++n > 50) clearInterval(iv); }, 300); }
})();

/* TERAFORMR in-window panel (2026-10-30 tfrcmd): MCR thundr_chat returns {action:"open_panel",url}; game opens inside ThundR's own window (iframe), never an external browser. Only 127.0.0.1/localhost. */
(function () {
  if (window.THUNDR_OPEN_PANEL) return;
  window.THUNDR_OPEN_PANEL = function (url, title) {
    if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+\//.test(String(url))) return;
    let p = document.getElementById("thundr-game-panel");
    if (!p) {
      p = document.createElement("div"); p.id = "thundr-game-panel";
      p.style.cssText = "position:fixed;inset:24px 8px 8px 8px;z-index:2147483646;background:#111;border:2px solid #6b4;border-radius:10px;display:flex;flex-direction:column;overflow:hidden";
      const bar = document.createElement("div"); bar.style.cssText = "display:flex;justify-content:space-between;align-items:center;padding:2px 8px;font:12px system-ui;color:#cfe;background:#253";
      bar.innerHTML = '<span class="tg-t"></span><button style="border:0;background:none;color:#fcc;font-size:14px;cursor:pointer" title="close">✕</button>';
      bar.querySelector("button").onclick = () => p.remove();
      const f = document.createElement("iframe"); f.style.cssText = "flex:1;border:0;width:100%;background:#000"; f.allow = "autoplay; fullscreen; gamepad";
      p.appendChild(bar); p.appendChild(f); document.body.appendChild(p);
    }
    p.querySelector(".tg-t").textContent = title || "TerraformЯ"; const f = p.querySelector("iframe"); if (f.src !== url) f.src = url;
    try { if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float) window.webkit.messageHandlers.float.postMessage({ op: "resize", w: 960, h: 600 }); } catch (e) {}
  };
})();

/* ThundR → GIZMO link (2026-10-30 gizmolink): posts rzl.gizmo.say into the TerraformЯ panel iframe (loopback only); GIZMO runs it like typed /gizmo input. */
(function () {
  window.THUNDR_GIZMO_OPEN = function () { window.THUNDR_OPEN_PANEL && fetch("http://127.0.0.1:8329/v1/call/thundr_chat", { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text: "TERAFORMR" }) }).then(function (r) { return r.json(); }).then(function (j) { var u = String((j && j.url) || ""); if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+\//.test(u)) u = "http://127.0.0.1:8323/"; window.THUNDR_OPEN_PANEL(u, "TerraformЯ · GIZMO link"); }).catch(function () { window.THUNDR_OPEN_PANEL("http://127.0.0.1:8323/", "TerraformЯ · GIZMO link"); }); }; /* rvm 20261030: URL from TERAFORMR-ENDPOINT via MCR */
  window.THUNDR_GIZMO_SAY = function (text) {
    const f = document.querySelector("#thundr-game-panel iframe");
    if (!f || !f.contentWindow || !/^http:\/\/(127\.0\.0\.1|localhost):\d+\//.test(String(f.src))) return false;
    f.contentWindow.postMessage(JSON.stringify({ type: "rzl.gizmo.say", text: String(text).slice(0, 500) }), new URL(f.src).origin);
    return true;
  };
  window.addEventListener("message", (e) => { if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(e.origin)) return; let m; try { m = JSON.parse(e.data); } catch (x) { return; }
    if (m && m.type) { window.THUNDR_GIZMO_LAST = m; console.log("gizmolink ←", m.type); } });
})();

/* backendfeed 2026-10-30 (pt353u): conversations sent to ThundR's backend (POST /v1/call/thundr_chat, gizmo_chat from bots/curl)
   also appear in this chat window, tagged "via backend · <source>". Reads MCR GET /v1/history (append-only thundr-chat.jsonl).
   Window-typed turns are skipped (no doubles); heartbeats/selfheal/status are skipped. Read-only; adds nothing to the server. */
(function () {
  if (window.THUNDR_BACKENDFEED) return; window.THUNDR_BACKENDFEED = true;
  const H = "http://127.0.0.1:8329/v1/history";
  const mine = []; // recent window-typed texts
  window.THUNDR_SENT = (q) => { mine.push({ q: String(q || "").trim(), t: Date.now() }); while (mine.length > 50) mine.shift(); };
  const SKIP = /^(thundr presence beat|selfheal-log:|selfheal-poll|status-live|thundr heal|bbx-hostread)/i; /* 2026-11-03 direct: BATIBABOX host reads (bbx-hostread) are machine polls, never chat */
  let last = -1, pendingQ = null;
  function isMine(q) { const now = Date.now(); for (let i = mine.length - 1; i >= 0; i--) { if (now - mine[i].t > 600000) break; if (mine[i].q === q) { mine.splice(i, 1); return true; } } return false; }
  function tick() {
    const u = last < 0 ? H + "?limit=1" : H + "?since=" + last;
    fetch(u).then((r) => r.json()).then((j) => {
      if (!j || !j.ok) return;
      if (last < 0) { last = j.last || 0; return; } // start at the end: no backlog flood
      last = j.last || last;
      (j.entries || []).forEach((e) => {
        const via = String(e.via || ""), txt = String(e.text || "");
        if (/^(presence|livestatus|selfheal|chat-view)$/.test(via)) return;
        if (e.role === "user") { pendingQ = (SKIP.test(txt.trim()) || isMine(txt.trim())) ? { skip: true } : { q: txt, src: e.source || "agent" }; if (!pendingQ.skip && window.THUNDR_FEED_SAY) window.THUNDR_FEED_SAY("[backend · " + pendingQ.src + "] " + txt, null, true); return; }
        if (e.role === "assistant") { const p = pendingQ; pendingQ = null; if (!p || p.skip) return; if (window.THUNDR_FEED_SAY) window.THUNDR_FEED_SAY(txt.replace(/THUNDR/g, "ThundR"), "backend · " + (via || p.src)); }
      });
    }).catch(() => {});
  }
  tick(); setInterval(tick, 3000);
})();


/* RCPM 2026-11-03: RCRYPTOPIPE monitor view inside the float. Typing RCPM shows a live block in the chat log (replaced in place every ~20 s via the
   read-only "rcpm-poll" call -> control room /v1/rcpm data) and says so in the feed when the abnormal count rises. Monitoring only: never kills/blocks anything.
   Auto-resumes after a float restart (localStorage thundr.rcpm=1); "RCPM OFF" stops it. */
(function () {
  if (window.THUNDR_RCPM) return;
  const NATIVE = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.float);
  const pend = {}; let timer = null, last = -1, box = null, installed = false, data = null;
  function install() { if (installed) return; installed = true; const prev = window.THUNDR_REPLY; window.THUNDR_REPLY = (id, body) => { const f = pend[id]; if (f) { delete pend[id]; f(body); } else if (prev) prev(id, body); }; }
  function poll() {
    if (!NATIVE) return fetch("http://127.0.0.1:8329/v1/rcpm").then((r) => r.json()).catch(() => null);
    return new Promise((res) => { install(); const id = 930000 + Math.floor(Math.random() * 99999); const to = setTimeout(() => { delete pend[id]; res(null); }, 60000);
      pend[id] = (b) => { clearTimeout(to); res(b && b.rcpm ? b.rcpm : (b && b.listeners ? b : null)); };
      try { window.webkit.messageHandlers.float.postMessage({ op: "call", id, tool: "thundr_chat", text: "rcpm-poll" }); } catch (e) { clearTimeout(to); delete pend[id]; res(null); } });
  }
  const mb = (n) => n >= 1e6 ? (n / 1e6).toFixed(1) + " MB" : Math.round(n / 1e3) + " KB";
  function render(d) {
    const log = document.querySelector("#th-chat .log"); if (!log || !d) return;
    if (!box || !box.isConnected) { box = document.createElement("div"); box.id = "th-rcpm"; box.style.cssText = "border:1px solid #2f7;border-radius:6px;padding:5px 7px;margin:6px 0;font:11px ui-monospace,Menlo,monospace;background:#031a0a;color:#9fffb8"; log.append(box); }
    const h = []; const bad = d.abnormal || [];
    h.push(["RCPM LIVE · " + (d.at || "") + " · " + (bad.length ? "✖ " + bad.length + " abnormal" : "✔ 0 abnormal"), bad.length ? "color:#ff8a8a;font-weight:700" : "color:#7dffb0;font-weight:700"]);
    h.push(["gate " + d.gate + " · pipe 8900 " + (d.pipe ? "up" : "DOWN") + " · " + (d.listeners || []).length + " listeners · " + (d.external || []).length + " ext conns", ""]);
    bad.forEach((a) => h.push(["✖ [" + a.kind + "] " + a.text, "color:#ffb3b3"]));
    if ((d.traffic_top || []).length) h.push(["traffic: " + d.traffic_top.slice(0, 4).map((t) => t.proc + " ↓" + mb(t.in) + " ↑" + mb(t.out)).join(" · "), "color:#8fd"]);
    if ((d.pipe_tail || []).length) h.push(["pipe: " + d.pipe_tail.slice(-2).join(" | "), "color:#888"]);
    box.replaceChildren(...h.map(([t, st]) => { const e = document.createElement("div"); e.textContent = t; if (st) e.style.cssText = st; return e; }));
    log.scrollTop = log.scrollHeight;
  }
  async function tick() {
    const d = await poll(); if (!d) return; data = d; render(d);
    const n = (d.abnormal || []).length;
    if (last >= 0 && n > last && window.THUNDR_FEED_SAY) window.THUNDR_FEED_SAY("⚠ RCPM: " + n + " abnormal (was " + last + "). " + (d.abnormal || []).slice(-1).map((a) => a.text).join(""), "rcpm");
    last = n;
  }
  function start(d0) {
    try { localStorage.setItem("thundr.rcpm", "1"); } catch (e) {}
    if (d0) { data = d0; last = (d0.abnormal || []).length; render(d0); }
    if (!timer) timer = setInterval(tick, 20000);
  }
  function stop() { clearInterval(timer); timer = null; last = -1; try { localStorage.removeItem("thundr.rcpm"); } catch (e) {} if (box) { box.remove(); box = null; } }
  window.THUNDR_RCPM = { start, stop, tick, active: () => !!timer, data: () => data };
  try { if (localStorage.getItem("thundr.rcpm") === "1") setTimeout(() => start(null), 4000); } catch (e) {}
})();
