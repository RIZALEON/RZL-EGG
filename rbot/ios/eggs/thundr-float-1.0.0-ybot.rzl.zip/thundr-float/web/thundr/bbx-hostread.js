/* bbx-hostread.js · THUNDR-FLOAT bridge for bbx-rt.js (2026-11-03 rewire). The float's WKWebView has only the "float" message handler, no rosHostRead.
 * This exposes window.RL_FLOAT_HOSTREAD.postMessage({op:"host.read",path,offset,len}) -> Promise<{ok,text,len,size}>, served read-only by the
 * control room (thundr_chat "bbx-hostread {...}", whitelisted to bbx-* files in MACHINE-MIND/DIGEST/BATIBA-SHARED). Calls are serialized. */
(function () {
  "use strict";
  if (window.RL_FLOAT_HOSTREAD) return;
  const pend = {}; let installed = false, chain = Promise.resolve();
  function install() {
    if (installed) return; installed = true; const prev = window.THUNDR_REPLY;
    window.THUNDR_REPLY = (id, body) => { const p = pend[id]; if (p) { delete pend[id]; p(body); } else if (prev) prev(id, body); };
  }
  function call(text) {
    return new Promise((res) => {
      let m; try { m = window.webkit.messageHandlers.float; } catch (e) {} if (!m) return res(null);
      install(); const id = 700000 + Math.floor(Math.random() * 99999); const to = setTimeout(() => { delete pend[id]; res(null); }, 60000);
      pend[id] = (b) => { clearTimeout(to); try { res(typeof b === "string" ? JSON.parse(b) : b); } catch (e) { res(null); } };
      try { m.postMessage({ op: "call", id, tool: "thundr_chat", text }); } catch (e) { clearTimeout(to); delete pend[id]; res(null); }
    });
  }
  window.RL_FLOAT_HOSTREAD = { postMessage(msg) {
    const run = () => call("bbx-hostread " + JSON.stringify({ name: String(msg.path || "").split("/").pop(), offset: msg.offset || 0, len: msg.len || 1048576 }))
      .then((r) => (r && r.ok ? { ok: true, text: r.text, len: r.len, size: r.size } : { ok: false }));
    const p = chain.then(run, run); chain = p.catch(() => {}); return p; } };
})();
