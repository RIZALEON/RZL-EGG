/* thundrsprite 2026-10-30: real ThundR 32px idle (12 frames @ 10 fps, thundr-live atlas) on the GIZMO link badge, beside GIZMO. Add-only. */
(function () {
  const c = document.createElement("style"); c.id = "thundr-gizmolink-sprite-css";
  c.textContent = "@keyframes thidle32{to{background-position:-384px 0}}.th-bot32{display:inline-block;width:32px;height:32px;background:url(thundr/gizmo/thundr-32-idle.webp) 0 0/384px 32px no-repeat;image-rendering:pixelated;animation:thidle32 1.2s steps(12) infinite;vertical-align:middle}";
  document.head.appendChild(c);
  function add() { const dk = document.getElementById("th-gz-dock"); if (!dk) return setTimeout(add, 600); if (!dk.querySelector(".th-bot32")) { const b = document.createElement("span"); b.className = "th-bot32"; b.title = "ThundR"; dk.insertBefore(b, dk.firstChild); } }
  add();
})();
