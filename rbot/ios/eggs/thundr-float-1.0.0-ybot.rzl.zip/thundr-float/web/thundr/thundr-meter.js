/* ThundR float meter 0.0.2 — tight strip between figure and label; fits 68x58; cycles OPTIMIZE. */
(function(){
 const css=document.createElement("style");css.textContent=`#th-meter{order:1;display:block!important;flex:0 0 auto;width:60px;margin:-8px auto 0;padding:0;pointer-events:none;background:none!important;border:0;box-shadow:none;line-height:1;position:relative;z-index:2}
#th-meter .tr{height:4px;border-radius:2px;background:rgba(255,255,255,.16);overflow:hidden}
#th-meter .f{height:100%;width:0;border-radius:2px;transition:width .8s,background .8s}
#th-meter .t{font:6px/1 Menlo,monospace;color:#cfe;text-align:center;text-shadow:0 0 2px #000;white-space:nowrap;margin:0;letter-spacing:-.2px}
#thundr-pin.th-orb{overflow:visible!important;height:auto!important;max-height:56px;gap:0!important}
#thundr-pin thundr-live,#thundr-pin .thundr-figure{order:0;margin:0 0 -10px!important;height:30px!important}
#thundr-pin .lbl{order:2;margin-top:-1px!important;position:relative;z-index:2}`;document.head.appendChild(css);
 const col=p=>p<50?"#2ecc71":p<70?"#f1c40f":p<85?"#ff8c1a":"#ff3b30";
 const grad=p=>`linear-gradient(90deg,#2ecc71 0%,#f1c40f ${Math.min(100,5000/Math.max(p,1))}%,${col(p)} 100%)`;
 function metrics(L){const m=[],r=L.ram_gb||8;
  if(L.ram_used_pct!=null)m.push(["RAM",L.ram_used_pct,(r*L.ram_used_pct/100).toFixed(1)+"/"+r+"GB"]);
  if(L.cpu_pct!=null)m.push(["CPU",L.cpu_pct,Math.round(L.cpu_pct)+"%"]);
  if(L.disk_used_pct!=null)m.push(["DISK",L.disk_used_pct,(L.disk_free_gb||0)+"GB free"]);
  if(L.inactive_mb!=null)m.push(["INACT",Math.min(100,L.inactive_mb/((r*1024)||8192)*400),L.inactive_mb+"MB"+(L.inactive_mb>500?" ↻":"")]);
  if(L.compressor_mb!=null)m.push(["COMP",Math.min(100,L.compressor_mb/2048*100),L.compressor_mb+"MB"]);
  if(L.swap_used_gb!=null)m.push(["SWAP",Math.min(100,L.swap_used_gb/4*100),L.swap_used_gb+"GB"]);
  if(L.load)m.push(["LOAD",Math.min(100,L.load[0]/(L.ncpu||6)*100),"1m "+L.load[0]]);
  const e=Object.entries(L.engines||{});if(e.length){const b=e.sort((a,c)=>(c[1].cpu||0)-(a[1].cpu||0))[0];m.push(["ENG "+b[0],b[1].up?Math.min(100,b[1].cpu||0):100,b[1].up?(b[1].cpu||0)+"% "+(b[1].rss_mb||0)+"MB":"down"]);}
  return m;}
 let i=0;
 function reload(){const s=document.createElement("script");s.src="thundr/live-status.js?t="+Date.now();s.onload=s.onerror=()=>s.remove();document.head.appendChild(s);}
 function tick(){const pin=document.getElementById("thundr-pin"),lbl=pin&&pin.querySelector(".lbl");if(!lbl)return;
  let el=document.getElementById("th-meter");if(el&&el.parentNode!==pin){el.remove();el=null;}if(!el){el=document.createElement("div");el.id="th-meter";el.innerHTML='<div class="tr"><div class="f"></div></div><div class="t"></div>';lbl.before(el);}else if(el.nextSibling!==lbl)lbl.before(el);
  try{if(!(window.THUNDR_JOBS&&window.THUNDR_JOBS.on&&window.THUNDR_JOBS.on())&&window.webkit&&webkit.messageHandlers.float&&(innerWidth>80||innerHeight>70))webkit.messageHandlers.float.postMessage({op:"status",open:false});}catch(e){}
  const m=metrics(window.LIVE||{});if(!m.length){el.querySelector(".t").textContent="OPTIMIZE …";return;}
  const hot=m.find(x=>x[1]>=85);const x=hot||m[i++%m.length];const p=Math.max(2,Math.min(100,x[1]));
  const f=el.querySelector(".f");f.style.width=p+"%";f.style.background=grad(p);el.querySelector(".t").textContent=x[0]+" "+x[2];}
 function forceSmall(){try{if(window.webkit&&webkit.messageHandlers.float){webkit.messageHandlers.float.postMessage({op:"status",open:false});webkit.messageHandlers.float.postMessage({op:"chat",open:false});}}catch(e){}}
 forceSmall();let _fs=0;const _fst=setInterval(()=>{forceSmall();if(++_fs>20)clearInterval(_fst);},500);
 reload();setInterval(reload,10000);setTimeout(tick,1200);setInterval(tick,6000);
})();
