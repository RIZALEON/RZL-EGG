/* GIZMO⇄ThundR link button (2026-10-30 ~20:00 MT, pt358u). Web layer only, no Swift change.
   GIZMO button in the ThundR chat header: press = link (opens TerraformЯ GIZMO panel via THUNDR_GIZMO_OPEN, sends a
   handshake through THUNDR_GIZMO_SAY), shows GIZMO as a small animated cryptobot (pheasant sheet 6×24px) in the chat.
   While linked, "@gizmo <msg>" goes to the game panel (or MCR gizmo_chat over loopback fetch if no panel), and GIZMO
   messages from the game iframe (rzl.gizmo.out / rzl.thundr.link) or backend history render tagged GIZMO.
   Press again = unlink. In-game THUNDR button handshake ("gizmolink handshake …" via thundr_chat) auto-links. */
(function () {
  if (window.THUNDR_GIZMOLINK) return;
  const st = { linked: false }; window.THUNDR_GIZMOLINK = st;
  const css = document.createElement("style"); css.id = "thundr-gizmolink-css";
  css.textContent = "@keyframes gzwalk{to{background-position:-168px 0}}" +
    ".gz-bot{display:inline-block;width:28px;height:28px;background:url(thundr/gizmo/gizmo_sheet.png) 0 0/168px 28px no-repeat;image-rendering:pixelated;animation:gzwalk .9s steps(6) infinite;vertical-align:middle}" +
    "#th-gz-dock{display:none;align-items:center;gap:6px;padding:2px 6px;font-size:11px;color:#f3d27a;background:#0004;border-radius:6px;margin:2px 4px}" +
    "#th-chat.gz-on #th-gz-dock{display:flex}.gz-line{color:#f3d27a}.gz-line .gz-bot{width:20px;height:20px;background-size:120px 20px;animation-name:gzwalk20;margin-right:4px}" +
    "@keyframes gzwalk20{to{background-position:-120px 0}}button.gz-btn.on{background:#c9a23a;color:#000}";
  document.head.appendChild(css);
  function gsay(t, via) {
    const log = document.querySelector("#th-chat .log"); if (!log) return;
    const d = document.createElement("div"); d.className = "gz-line";
    const b = document.createElement("span"); b.className = "gz-bot"; d.append(b, document.createTextNode("GIZMO · " + String(t).slice(0, 800)));
    const v = document.createElement("div"); v.className = "via"; v.textContent = "via " + (via || "gizmolink"); d.append(v);
    log.append(d); log.scrollTop = log.scrollHeight;
  }
  window.THUNDR_GIZMO_FEED = gsay;
  function setLinked(on, why) {
    st.linked = !!on; const chat = document.getElementById("th-chat"); if (!chat) return;
    chat.classList.toggle("gz-on", st.linked);
    const btn = chat.querySelector("button.gz-btn"); if (btn) btn.classList.toggle("on", st.linked);
    const lbl = document.getElementById("th-gz-lbl"); if (lbl) lbl.textContent = "GIZMO linked · " + (why || "ThundR window");
  }
  function trySay(t, n) { if (window.THUNDR_GIZMO_SAY && window.THUNDR_GIZMO_SAY(t)) return true; if (n > 0) setTimeout(() => trySay(t, n - 1), 1500); return false; }
  function link() {
    setLinked(true, "ThundR window");
    if (!document.querySelector("#thundr-game-panel iframe") && window.THUNDR_GIZMO_OPEN) window.THUNDR_GIZMO_OPEN();
    trySay("/gizmo ThundR link: hello from the external ThundR window", 6);
    gsay("Linked with ThundR. Type @gizmo <message> to talk to me here.", "gizmolink");
  }
  function unlink() { setLinked(false); trySay("/gizmo ThundR link: unlinked", 0); gsay("Unlinked from ThundR.", "gizmolink"); }
  window.THUNDR_GIZMO_LINK = (on) => (on === false ? unlink() : link());
  function mount() {
    const chat = document.getElementById("th-chat"); if (!chat) return setTimeout(mount, 500);
    const hd = chat.querySelector(".hd"), x = hd && hd.querySelector("button[data-x]");
    if (hd && !hd.querySelector("button.gz-btn")) {
      const b = document.createElement("button"); b.className = "gz-btn"; b.textContent = "GIZMO"; b.title = "Link GIZMO with ThundR";
      b.addEventListener("click", (e) => { e.stopPropagation(); st.linked ? unlink() : link(); }, true);
      hd.insertBefore(b, x || null);
    }
    if (!document.getElementById("th-gz-dock")) {
      const dk = document.createElement("div"); dk.id = "th-gz-dock"; dk.innerHTML = '<span class="gz-bot"></span><span id="th-gz-lbl">GIZMO linked</span>';
      const lg = chat.querySelector(".log"); chat.insertBefore(dk, lg || null);
    }
    const inp = chat.querySelector(".row input");
    if (inp && !inp.dataset.gz) { inp.dataset.gz = "1"; inp.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" || !st.linked) return; const m = /^@gizmo\b[:,]?\s*(.+)$/i.exec(inp.value.trim()); if (!m) return;
      e.stopImmediatePropagation(); e.preventDefault(); const q = m[1]; inp.value = "";
      window.THUNDR_FEED_SAY && window.THUNDR_FEED_SAY("@gizmo " + q, null, true);
      if (trySay(q, 0)) return;
      fetch("http://127.0.0.1:8329/v1/call/gizmo_chat", { method: "POST", headers: { "Content-Type": "text/plain" }, body: JSON.stringify({ text: "/gizmo " + q }) })
        .then((r) => r.json()).then((j) => gsay(String(j.reply || j.output || j.error || JSON.stringify(j)), "MCR gizmo_chat")).catch((er) => gsay("No game panel and MCR gizmo_chat unreachable (" + er + ")", "error"));
    }, true); }
  }
  mount();
  // GIZMO messages from the TerraformЯ panel iframe (loopback origins only)
  window.addEventListener("message", (e) => {
    if (!/^http:\/\/(127\.0\.0\.1|localhost):\d+$/.test(e.origin)) return; let m; try { m = JSON.parse(e.data); } catch (x) { return; }
    if (!m) return;
    if (m.type === "rzl.thundr.link") { setLinked(m.on !== false, "in-game THUNDR button"); gsay(m.on === false ? "In-game ThundR dismissed." : "In-game ThundR summoned — linked.", "TerraformЯ"); }
    else if (m.type === "rzl.gizmo.out" && st.linked && m.text) gsay(m.text, "TerraformЯ GIZMO");
  });
  // backend handshake / gizmo_chat replies (MCR history, read-only)
  const H = "http://127.0.0.1:8329/v1/history"; let last = -1, pend = null;
  function tick() {
    fetch(last < 0 ? H + "?limit=1" : H + "?since=" + last).then((r) => r.json()).then((j) => {
      if (!j || !j.ok) return; if (last < 0) { last = j.last || 0; return; } last = j.last || last;
      (j.entries || []).forEach((e) => { const t = String(e.text || "");
        if (e.role === "user") { if (/^gizmolink handshake/i.test(t)) { const off = /unlink|dismiss/i.test(t); setLinked(!off, "in-game THUNDR button"); gsay(off ? "In-game ThundR dismissed (handshake)." : "Handshake from TerraformЯ: in-game ThundR summoned — linked.", "backend · " + (e.source || "terraformr")); }
          pend = /^\/?gizmo\b/i.test(t) || /gizmo/i.test(String(e.via || "")) ? 1 : null; return; }
        if (e.role === "assistant" && st.linked && (pend || /gizmo/i.test(String(e.via || "")))) gsay(t, "backend · gizmo"); pend = null; });
    }).catch(() => {});
  }
  tick(); setInterval(tick, 3000);
})();
