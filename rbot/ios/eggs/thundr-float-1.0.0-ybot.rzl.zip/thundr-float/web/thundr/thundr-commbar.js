/* ThundR Command Chat Comm Bar (DOS style). Reuses the existing #th-chat input → ask() → thundr_chat path; no new network. 2026-10-26 */
(function(){function boot(){var c=document.getElementById("th-chat");if(!c||c.querySelector(".th-comm"))return!!c;
var hd=c.querySelector(".hd"),main=c.querySelector(".row input");if(!hd||!main)return true;
var b=document.createElement("div");b.className="th-comm";b.innerHTML='<label>R:\\&gt;</label><input spellcheck="false" autocomplete="off" aria-label="ThundR command"><i class="cur"></i><button type="button">SEND</button>';
var x=hd.querySelector("[data-x]");(x?x:hd.lastChild).after(b);
var inp=b.querySelector("input"),H=[],k=0;function fit(){inp.style.width=Math.max(1,inp.value.length+1)+"ch";}inp.addEventListener("input",fit);b.addEventListener("click",function(e){if(e.target.tagName!=="BUTTON")inp.focus();});
function send(){var q=inp.value.trim();if(!q)return;H.push(q);k=H.length;inp.value="";fit();main.value=q;main.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:true}));c.querySelectorAll(".q").forEach(function(e){if(!e.dataset.dos){e.dataset.dos=1;e.textContent="R:\\> "+e.textContent.replace(/^\s*[›>]\s*/,"");}});}
inp.addEventListener("keydown",function(e){e.stopPropagation();if(e.key==="Enter"){e.preventDefault();send();}
else if(e.key==="ArrowUp"&&H.length){e.preventDefault();k=Math.max(0,k-1);inp.value=H[k];fit();}
else if(e.key==="ArrowDown"&&H.length){e.preventDefault();k=Math.min(H.length,k+1);inp.value=H[k]||"";fit();}});
fit();b.querySelector("button").onclick=send;
/* 2026-10-29 repair: (a) focus R:\> when the panel opens · (c) stick to newest reply unless user scrolled up · (d) no clipped text */
var lg=c.querySelector(".log"),stick=true;if(lg){lg.addEventListener("scroll",function(){stick=lg.scrollHeight-lg.scrollTop-lg.clientHeight<24;});
new MutationObserver(function(){if(stick)lg.scrollTop=lg.scrollHeight;}).observe(lg,{childList:true,subtree:true,characterData:true});}
var wasOpen=false;new MutationObserver(function(){var o=c.classList.contains("open");if(o&&!wasOpen){stick=true;setTimeout(function(){inp.focus();if(lg)lg.scrollTop=lg.scrollHeight;},120);}wasOpen=o;}).observe(c,{attributes:true,attributeFilter:["class"]});
if(c.classList.contains("open"))setTimeout(function(){inp.focus();},120);
var css=document.createElement("style");css.textContent="#th-chat .log{overflow-y:auto;overflow-x:hidden;word-break:break-word;overflow-wrap:anywhere;min-height:120px}#th-chat .log>div{margin:2px 0}#th-chat .q{color:#9ad0ff}";document.head.append(css);
window.THUNDR_COMMBAR={send:function(q){inp.value=q;send();},history:H};return true;}
if(!boot()){var n=0,iv=setInterval(function(){if(boot()||++n>50)clearInterval(iv)},200);}})();
